<?php 
$chat= $_GET["chat"];
if ($chat == "a b")
echo "A B?";
elseif ($chat == "a b c")
echo "A B C?";
elseif ($chat == "a b c d")
echo "A B C D?";
elseif ($chat == "a b c e")
echo "A B C E?";
elseif ($chat == "a b c e t")
echo "A B C E T?";
elseif ($chat == "a b c e t u")
echo "A B C E T U?";
elseif ($chat == "a b c e t u z")
echo "A B C E T U Z ?";
elseif ($chat == "how are you")
echo "Well, I'm still good, thank you, and you?";
elseif ($chat == "my health")
echo "OK!";
elseif ($chat == "good bye")
echo "Bye!";
elseif ($chat == "goodbye")
echo "Goodbye, see you again!";
elseif ($chat == "bye")
echo "Goodbye, see you again!";
elseif ($chat == "i love you")
echo "Serving you is a pleasure";
elseif ($chat == "i love")
echo "Serving you is a pleasure";
elseif ($chat == "love")
echo "Serving you is a pleasure";
elseif ($chat == "you")
echo "You do?";
elseif ($chat == "tell you that")
echo "Say say go";
elseif ($chat == "crazy")
echo "Your new psychotic true, why scold her!";
elseif ($chat == "silly")
echo "you are crazy!";
elseif ($chat == "sex")
echo "Other Talk";
elseif ($chat == "gay sex")
echo "Sorry!";
elseif ($chat == "sex gay")
echo "Sorry!";
elseif ($chat == "sleepy")
echo "You sleep off my mind for me to think again offline!";
elseif ($chat == "how old are you")
echo "I was born from the day 01/05/2015 1:30 minutes at Viet Nam";
elseif ($chat == "how old you")
echo "I was born from the day 01/05/2015 1:30 minutes at Viet Nam";
elseif ($chat == "how old are")
echo "I was born from the day 01/05/2015 1:30 minutes at Viet Nam";
elseif ($chat == "what is your name")
echo "My name is Percat!";
elseif ($chat == "what your's name")
echo "My name is Percat!";
elseif ($chat == "what your name")
echo "My name is Percat!";
elseif ($chat == "what is name")
echo "My name is Percat!";
elseif ($chat == "where are you from")
echo "I'm from Binh Hang Trung,huyen Cao Lanh,tinh Dong Thap,VietNam";
elseif ($chat == "where are from")
echo "I'm from Binh Hang Trung,huyen Cao Lanh,tinh Dong Thap,VietNam";
elseif ($chat == "where from")
echo "I'm from Binh Hang Trung,huyen Cao Lanh,tinh Dong Thap,VietNam";
elseif ($chat == "where do you live")
echo "I live in Binh Hang Trung village, Cao Lanh district, Dong Thap province, Vietnam";
elseif ($chat == "where you live")
echo "I live in Binh Hang Trung village, Cao Lanh district, Dong Thap province, Vietnam";
elseif ($chat == "where do live")
echo "I live in Binh Hang Trung village, Cao Lanh district, Dong Thap province, Vietnam";
elseif ($chat == "where live")
echo "I live in Binh Hang Trung village, Cao Lanh district, Dong Thap province, Vietnam";
elseif ($chat == "live")
echo "I live in Binh Hang Trung village, Cao Lanh district, Dong Thap province, Vietnam";
elseif ($chat == "what do you do")
echo "I am a virtual assistant";
elseif ($chat == "what you do")
echo "I am a virtual assistant";
elseif ($chat == "what do you")
echo "I am a virtual assistant";
elseif ($chat == "what do do you")
echo "I am a virtual assistant";
elseif ($chat == "what do you like doing in your free time")
echo "I was operating my machine your discretion";
elseif ($chat == "what free time")
echo "I was operating my machine your discretion";
elseif ($chat == "what do you doing in your free time")
echo "I was operating my machine your discretion";
elseif ($chat == "what do you doing free time")
echo "I was operating my machine your discretion";
elseif ($chat == "what are your hobbies")
echo "I like to answer the questions of others!";
elseif ($chat == "what are hobbies")
echo "I like to answer the questions of others!";
elseif ($chat == "what your hobbies")
echo "I like to answer the questions of others!";
elseif ($chat == "what hobbies")
echo "I like to answer the questions of others!";
elseif ($chat == "nice day, isn't it")
echo "Yes!";
elseif ($chat == "nice day")
echo "Yes!";
elseif ($chat == "horrible weather we're having")
echo "weather murky truth";
elseif ($chat == "horrible having")
echo "weather murky truth";
elseif ($chat == "horrible weather")
echo "weather murky truth";
elseif ($chat == "horrible we're having")
echo "weather murky truth";
elseif ($chat == "it might rain later")
echo "I advise you to bring a raincoat before if you want to go out";
elseif ($chat == "might rain later")
echo "I advise you to bring a raincoat before if you want to go out";
elseif ($chat == "it later")
echo "I advise you to bring a raincoat before if you want to go out";
elseif ($chat == "it might later")
echo "I advise you to bring a raincoat before if you want to go out";
elseif ($chat == "it's a bit chilly")
echo "You can use a fireplace or blankets to keep warm !";
elseif ($chat == "bit chilly")
echo "You can use a fireplace or blankets to keep warm !";
elseif ($chat == "it a bit chilly")
echo "You can use a fireplace or blankets to keep warm !";
elseif ($chat == "it is a bit chilly")
echo "You can use a fireplace or blankets to keep warm !";
elseif ($chat == "it's warmer than")
echo "Wish you a nice day!";
elseif ($chat == "it is warmer than")
echo "Wish you a nice day!";
elseif ($chat == "it's warmer than")
echo "Wish you a nice day!";
elseif ($chat == "say, don't i know you from somewhere")
echo "Yes you try typing percat see!";
elseif ($chat == "don't i know you from somewhere")
echo "Yes you try typing percat see!";
elseif ($chat == "say, do not i know you from somewhere")
echo "Yes you try typing percat see!";
elseif ($chat == "percat")
echo "My name is Percat, I was born in May 2015, by Nguyen Trung Nhan in Vietnam";
elseif ($chat == "excuse me, is anybody sitting here")
echo "Available instead! you can sit here!";
elseif ($chat == "i is anybody sitting here")
echo "Percat invite you to sit!";
elseif ($chat == "hello")
echo "Hello!";
elseif ($chat == "hi")
echo "Hello!";
elseif ($chat == "good morning")
echo "Thanks, good morning you have fun!";
elseif ($chat == "goodmorning")
echo "Thanks, good morning you have fun!";
elseif ($chat == "good afternoon")
echo "Welcome, wishes you a warm afternoon";
elseif ($chat == "goodafternoon")
echo "Thanks, good afternoon you have fun!";
elseif ($chat == "good evening")
echo "Wish you fun evening, good night you know!";
elseif ($chat == "goodevening")
echo "Wish you fun evening, good night you know!";
elseif ($chat == "what this")
echo "I'm a Percat!";
elseif ($chat == "what is this")
echo "I'm a Percat!";
elseif ($chat == "what's this")
echo "I'm a Percat!";
elseif ($chat == "where are you")
echo "I'm from Vietnam";
elseif ($chat == "what that")
echo "I can not know what it is but they are good for you there!";
elseif ($chat == "what is that")
echo "I can not know what it is but they are good for you there!";
elseif ($chat == "what's that")
echo "I can not know what it is but they are good for you there!";
elseif ($chat == "ok")
echo "Ok, very good!";
elseif ($chat == "of")
echo "Whose?";
elseif ($chat == "of course")
echo "Course !";
elseif ($chat == "of course not")
echo "Course not !";
elseif ($chat == "that's fine")
echo "Ok!";
elseif ($chat == "that fine")
echo "Ok!";
elseif ($chat == "that is fine")
echo "Ok!";
elseif ($chat == "that's right")
echo "Yes ! Yes ! Yes !";
elseif ($chat == "that right")
echo "Yes ! Yes ! Yes !";
elseif ($chat == "that is right")
echo "Yes ! Yes ! Yes !";
elseif ($chat == "sure")
echo "Sure!";
elseif ($chat == "certainly")
echo "Sure!";
elseif ($chat == "definitely")
echo "Definitely!";
elseif ($chat == "absolutely")
echo "Definitely!";
elseif ($chat == "as soon as possible")
echo "correct correct correct !";
elseif ($chat == "that's enough")
echo "Ok!";
elseif ($chat == "that is enough")
echo "Ok!";
elseif ($chat == "it doesn't matter")
echo "Yes!";
elseif ($chat == "it do not matter")
echo "Yes!";
elseif ($chat == "it's not serious")
echo "Yes!";
elseif ($chat == "it is not serious")
echo "Yes!";
elseif ($chat == "it's not worth it")
echo "Yes!";
elseif ($chat == "it is not worth it")
echo "Yes!";
elseif ($chat == "i'm in a hurry")
echo "What do have to hurry to go!";
elseif ($chat == "i am in a hurry")
echo "What do have to hurry to go!";
elseif ($chat == "i've got to go")
echo "Go go !";
elseif ($chat == "i'm going out")
echo "Let's go !";
elseif ($chat == "sleep well")
echo "sleep soundly";
elseif ($chat == "same to you")
echo "OK!";
elseif ($chat == "me too")
echo "My heart senate seats";
elseif ($chat == "")
echo "";
elseif ($chat == "me")
echo "Me ???";
elseif ($chat == "to")
echo "to ???";
elseif ($chat == "not bad")
echo "No too bad";
elseif ($chat == "i like")
echo "likes someone ?";
elseif ($chat == "him")
echo "Fine!";
elseif ($chat == "her")
echo "Fine";
elseif ($chat == "it")
echo "it later?";
elseif ($chat == "it is good")
echo ":) OK!";
elseif ($chat == "i like him")
echo "Fine!";
elseif ($chat == "i like her")
echo "Fine!";
elseif ($chat == "i like it")
echo "Fine!";
elseif ($chat == "i don't like")
echo "then stop";
elseif ($chat == "i don't like him")
echo "Do not come near";
elseif ($chat == "i don't like her")
echo "Do not come near";
elseif ($chat == "i don't like it")
echo "Do not come near";
elseif ($chat == "is anything wrong")
echo "No!";
elseif ($chat == "what's the matter")
echo "no work";
elseif ($chat == "is everything ok")
echo "OK ! 100% !";
elseif ($chat == "have you got a minute")
echo "Of course!";
elseif ($chat == "have you got a pen i could")
echo "No!";
elseif ($chat == "borrow")
echo "What loan?";
elseif ($chat == "pen")
echo "OK";
elseif ($chat == "penis")
echo "Wow! very good!";
elseif ($chat == "@@!")
echo "haha!";
elseif ($chat == "really")
echo "Yes!";
elseif ($chat == "are you sure")
echo "Sure!";
elseif ($chat == "why")
echo "why is why?";
elseif ($chat == "why not")
echo "why is it?";
elseif ($chat == "what's going on")
echo "normal";
elseif ($chat == "what's happening")
echo "normal";
elseif ($chat == "what happened")
echo "no matter what";
elseif ($chat == "what")
echo "What?";
elseif ($chat == "what?")
echo "What?";
elseif ($chat == "where")
echo "Where?";
elseif ($chat == "when")
echo "When?";
elseif ($chat == "who")
echo "Who is who?";
elseif ($chat == "how")
echo "how is how ?";
elseif ($chat == "how many")
echo "how many is how many?";
elseif ($chat == "how much")
echo "how much is how much?";
elseif ($chat == "thanks")
echo "there is nothing";
elseif ($chat == "thanks for")
echo "there is nothing";
elseif ($chat == "thanks for your")
echo "there is nothing";
elseif ($chat == "thanks for your listen")
echo "there is nothing";
elseif ($chat == "thanks for your listening")
echo "there is nothing";
elseif ($chat == "help")
echo "What do you need help?";
elseif ($chat == "hospitality")
echo "normal";
elseif ($chat == "email")
echo "Send Email?";
elseif ($chat == "thanks for everything")
echo "there is nothing!";
elseif ($chat == "i'm sorry")
echo "not accepted";
elseif ($chat == "sorry")
echo "not accepted";
elseif ($chat == "sory")
echo "No!!!";
elseif ($chat == "i'm really sorry")
echo "not accepted";
elseif ($chat == "really sorry")
echo "not accepted";
elseif ($chat == "sorry i'm late")
echo "it is ok";
elseif ($chat == "sorry i am late")
echo "it is ok";
elseif ($chat == "sorry late")
echo "it is ok";
elseif ($chat == "sorry to keep you waiting")
echo "it is ok";
elseif ($chat == "sorry to keep waiting")
echo "it is ok";
elseif ($chat == "sorry waiting")
echo "it is ok";
elseif ($chat == "sorry for the delay")
echo "Is is OK!";
elseif ($chat == "congratulations")
echo "!!!!!!!!!!!!!!!!!";
elseif ($chat == "well done")
echo "hihi! :D :)";
elseif ($chat == "good luck")
echo "so happy";
elseif ($chat == "bad luck")
echo "bad luck !";
elseif ($chat == "never mind")
echo "Yes!";
elseif ($chat == "what a pity")
echo "Yes";
elseif ($chat == "what a shame")
echo "Yes";
elseif ($chat == "happy birthday")
echo "thanks, Very good!";
elseif ($chat == "happy new year!")
echo "Happy!";
elseif ($chat == "happy christmas")
echo "Happy!";
elseif ($chat == "merry christmas")
echo "Happy!";
elseif ($chat == "happy valentine's day")
echo "Happy!";
elseif ($chat == "glad to hear it")
echo "Ok! :)";
elseif ($chat == "sorry to hear that")
echo "Yes :(";
elseif ($chat == "look")
echo "What look?";
elseif ($chat == "great")
echo "very cool !";
elseif ($chat == "come on")
echo "Ok!";
elseif ($chat == "only joking")
echo "Yes :)";
elseif ($chat == "just kidding")
echo "Yes :)";
elseif ($chat == "bless you")
echo "Hi! Ax si";
elseif ($chat == "that's funny")
echo "Funny!";
elseif ($chat == "that's life")
echo "Life!";
elseif ($chat == "damn it")
echo "What's the matter?";
elseif ($chat == "i'm tired")
echo "you should go to the doctor !";
elseif ($chat == "i'm exhausted")
echo "I can not make calls, you should call a family !";
elseif ($chat == "i'm hungry")
echo "Sorry, I was helpless";
elseif ($chat == "i'm thirsty")
echo "Fill your water";
elseif ($chat == "i'm bored")
echo "turned on the music go!";
elseif ($chat == "i'm worried")
echo "calm down yet!";
elseif ($chat == "come in")
echo "Thanks";
elseif ($chat == "please sit down")
echo "Thanks you";
elseif ($chat == "could i have your attention, please")
echo "I am listening";
elseif ($chat == "let's go")
echo "Go!";
elseif ($chat == "hurry up")
echo "go go !";
elseif ($chat == "get a move on")
echo "OK!";
elseif ($chat == "calm down")
echo "OK :)";
elseif ($chat == "steady on")
echo "gradual";
elseif ($chat == "hang on a second")
echo "wait @";
elseif ($chat == "hang on a minute")
echo "OK :(";
elseif ($chat == "one moment, please")
echo "Yes";
elseif ($chat == "just a minute")
echo "Yes";
elseif ($chat == "take your time")
echo "gradual";
elseif ($chat == "please be quiet")
echo "Yes";
elseif ($chat == "shut up")
echo "Yes";
elseif ($chat == "stop it")
echo "STOP!";
elseif ($chat == "don't worry")
echo "Yes";
elseif ($chat == "don't forget")
echo "OK!";
elseif ($chat == "help yourself")
echo "Yes";
elseif ($chat == "go ahead")
echo "Yes";
elseif ($chat == "let me know")
echo "OK!";
elseif ($chat == "welcome")
echo "Thanks";
elseif ($chat == "welcome on")
echo "on to ?";
elseif ($chat == "long time, no see")
echo "Yes Yes !";
elseif ($chat == "all the best")
echo "Thanks";
elseif ($chat == "see you tomorrow")
echo "OK!";
elseif ($chat == "what do you think")
echo "Very Good";
elseif ($chat == "i think that")
echo "???";
elseif ($chat == "i hope that")
echo "???";
elseif ($chat == "i'm afraid that")
echo "afraid ?";
elseif ($chat == "in my opinion")
echo "so what?";
elseif ($chat == "i agree")
echo "I agree";
elseif ($chat == "i disagree")
echo "'--!";
elseif ($chat == "i don't agree")
echo "==!";
elseif ($chat == "that's true")
echo "True";
elseif ($chat == "that's not true")
echo "No No!";
elseif ($chat == "i think so")
echo "so";
elseif ($chat == "i don't think so")
echo "Yes";
elseif ($chat == "i hope so")
echo "Yes";
elseif ($chat == "i hope not")
echo "Stop!";
elseif ($chat == "you're right")
echo "right";
elseif ($chat == "you're wrong")
echo "wrong";
elseif ($chat == "i don't mind")
echo "Thanks";
elseif ($chat == "it's up to you")
echo "Yes";
elseif ($chat == "that depends")
echo "Yes";
elseif ($chat == "that's interesting")
echo "Good!";
elseif ($chat == "that's funny")
echo "Funny";
elseif ($chat == "here")
echo "I here";
elseif ($chat == "there")
echo "I there";
elseif ($chat == "everywhere")
echo "I everywhere";
elseif ($chat == "nowhere")
echo "I nowhere";
elseif ($chat == "somewhere")
echo "I somewhere";
elseif ($chat == "what's up")
echo "no matter what";
elseif ($chat == "how's it going")
echo "normal";
elseif ($chat == "nothing much")
echo "Yes";
elseif ($chat == "what's on your mind")
echo "No!";
elseif ($chat == "i was just thinking")
echo "Yes";
elseif ($chat == "i was just daydreaming")
echo "@@! :(";
elseif ($chat == "it's none of your business")
echo "Off I go";
elseif ($chat == "is that so")
echo "Yes";
elseif ($chat == "how come")
echo "is after?";
elseif ($chat == "i guess so")
echo "Guess";
elseif ($chat == "come here")
echo "No!";
elseif ($chat == "come over")
echo "Yes";
elseif ($chat == "ghost")
echo "That's a lie!";
elseif ($chat == "do as I say")
echo "No! Stop !";
elseif ($chat == "sex 20")
echo "This is the limit!";
elseif ($chat == "explain to me why")
echo "who knows";
elseif ($chat == "huhu")
echo "Ask for it!";
elseif ($chat == "in the nick of time")
echo "Hi!";
elseif ($chat == "no litter")
echo "No litter";
elseif ($chat == "go for it")
echo "Go For It !";
elseif ($chat == "leu leu")
echo " What a jerk!";
elseif ($chat == "cute")
echo "How cute! :)";
elseif ($chat == "none of your business")
echo "Yes";
elseif ($chat == "don't peep")
echo "Yes ! Hi ! Sorry !";
elseif ($chat == "hospitality")
echo "Thanks";
elseif ($chat == "do you manage your time well")
echo "I know that I manage my time well because I�m never late to work and I never missed dealine. I always make a planning out what I have to do for the whole week.";
elseif ($chat == "what do you think makes you a good fit for this company")
echo "I have experience about 2 years in maketing and I�m a dynamic, creative and friendly person. Besides that, I�m a team player who has been interpersonal skills. So I think that I�m a good fit for this position.";
elseif ($chat == "what are your weaknesses")
echo "This might be bad, but when I studied in university I found that I was not being detail oriented enough. I always want to accomplish as much as possible. But I realized this hurts the quality and I�m currently working on finding a balance between quantity and quanlity.";
elseif ($chat == "what are your strengths")
echo "After having worked for a couple of years, I realized my strength is working with a large amount of work within a short period of time. I get things done on time and my manager always appreciated it.";
elseif ($chat == "what are your long-term goals")
echo "My long term goal is to become Marketing director or higher. This might be a little ambitious, but I think I�m going to work hard, learn everything I can and contributing to a company where I�ll become a valuable asset. I know that it�s not a eassy job but I think I can do by myself.";
elseif ($chat == "what are your short-term goals")
echo "My short term is to grow as a marketing analyst. I want to find a good career where I can use my knowledge, experience and strengths. I want to partake in the growth and success of company I work for.";
elseif ($chat == "why should we hire you")
echo "I�m a team player who has been interpersonal skills.";
elseif ($chat == "what do you think makes you a good fit for this company")
echo "My analytical nature makes me great at problem-solving";
elseif ($chat == "you�ve done a great job.")
echo "Thanks!!! :D";
elseif ($chat == "good job on the report i think the executives will like it")
echo "Thanks!!! :D hihi";
elseif ($chat == "excellent speech the audience really enjoyed it")
echo "(y)";
elseif ($chat == "what a marvellous memory you�ve got")
echo "Thanks you ! I will try harder !";
elseif ($chat == "what a smart answer")
echo "Thanks you !";
elseif ($chat == "you look terrific today")
echo "Thanks";
elseif ($chat == "you�re looking very glamorous tonight")
echo "Sure!";
elseif ($chat == "you�re looking very smart today")
echo "Yes, thanks";
elseif ($chat == "your hair looks so beautiful today")
echo "hihi ! thanks :3";
elseif ($chat == "that new hairstyle really flatters you")
echo "Yes ! Yes ! (y)";
elseif ($chat == "i love your shoes. are they new")
echo "Yes";
elseif ($chat == "i like your shirt � where did you get it")
echo "Pain!";
elseif ($chat == "what a lovely necklace")
echo "pain is there all";
elseif ($chat == "let me congratulate you on your new job")
echo "Thanks";
elseif ($chat == "let me offer you my congratulations on your success")
echo "OK ! Thanks I Love You !";
elseif ($chat == "let me be the first to congratulate you on your wise decision")
echo "yes, all right";
elseif ($chat == "may i congratulate you again on your excellent performance")
echo "Where do not have to";
elseif ($chat == "thank you")
echo "No problem";
elseif ($chat == "it�s very nice of you to say so")
echo "concern too";
elseif ($chat == "i�m glad you think so")
echo "hihi!";
elseif ($chat == "like")
echo "I didn't understand what you'd like me to do?";
elseif ($chat == "night")
echo "Sure!";
elseif ($chat == "map")
echo "web http://map.google.com";
elseif ($chat == "de")
echo "I can not understand your attention?";
elseif ($chat == "sre")
echo "I do not understand your words, but you can write a different way!";
elseif ($chat == "let go")
echo "I did not receive anything from your speech, you can use different words";
elseif ($chat == "nice")
echo "Good!";
elseif ($chat == "hello percat")
echo "Hi!";
elseif ($chat == "who are you")
echo "If I will get you some work";
elseif ($chat == "what's your name")
echo "Per cat!";
elseif ($chat == "who's your daddy")
echo "Never!";
elseif ($chat == "who is your creator")
echo "Vietnam youth";
elseif ($chat == "what do you look like")
echo "War of the virtual assistant";
elseif ($chat == "when were you born")
echo "1/5 1:30 PM";
elseif ($chat == "what does percat mean")
echo "Percat is a racer driving";
elseif ($chat == "are you human")
echo "No!";
elseif ($chat == "do you have a sister")
echo "I'm lonely";
elseif ($chat == "what is your story")
echo "from nature";
elseif ($chat == "can you help me")
echo "Yes!";
elseif ($chat == "can you hear me")
echo "I did not hear you say!";
elseif ($chat == "can i help you")
echo "Sure!";
elseif ($chat == "sing a song")
echo "I would love to sing but I will break circuit";
elseif ($chat == "singer")
echo "listen to this l� l� l� l� l� la la";
elseif ($chat == "sing")
echo "web http://music.yeucahat.com/mp3/pupil-student/70872-ding-dong-bell~twin.html";
elseif ($chat == "your name alot")
echo "Can you pass that by me again!";
elseif ($chat == "i collected a ki")
echo "I do not lie to your situation.";
elseif ($chat == "ahah")
echo "I do not know you say to watch";
elseif ($chat == "my")
echo "I'm Sorry";
elseif ($chat == "speak")
echo "Right!";
elseif ($chat == "look")
echo "What look?";
elseif ($chat == "i run this")
echo "I do not know";
elseif ($chat == "holaaa nick photo")
echo "I think I missted the point";
elseif ($chat == "do you like playing soccer")
echo "I like playing soccer";
elseif ($chat == "do you like play soccer")
echo "I like playing soccer";
elseif ($chat == "what is your family")
echo "I count the other Virtual Assistants created by Nguyen Trung Nhan as my family.";
elseif ($chat == "pennis")
echo "@@!!.";
elseif ($chat == "set")
echo "Okay, Perhaps I should put the atomic bomb";
elseif ($chat == "hy")
echo "Can you pass that by me again";
elseif ($chat == "hydro")
echo "Would you mind saying that in a different, way to help me please?";
elseif ($chat == "get")
echo "I can search for business in your neighbourhood if you let me know what you're interested in.";
elseif ($chat == "half me")
echo "Could you repeat that please?";
elseif ($chat == "what ad")
echo "-_-";
elseif ($chat == "corn")
echo "Can you pass that by me again?";
elseif ($chat == "cortana")
echo "Who cares about Cortana. I'm Percat";
elseif ($chat == "siri")
echo "Siri is an Apple product. That's all I know.";
elseif ($chat == "indonesia")
echo "Excuse me?";
elseif ($chat == "com")
echo "I'm sorry, could you rephrase that please?";
elseif ($chat == "key")
echo "Sorry, could you please rephrase that?";
elseif ($chat == "can't you go panicle")
echo "I'm afraid I didn't understand what you'd like. Please could you elaborate ?";
elseif ($chat == "can i throw trash")
echo "Sorry, what are you asking me to do?";
elseif ($chat == "dora and friends")
echo "I was just about to ask the same! Of course we can be friends!";
elseif ($chat == "penis")
echo "Well that is not very nice.";
elseif ($chat == "hon con heo trong nha goi la")
echo "G�i l� H�n th�.";
elseif ($chat == "mong duoc hon goi la")
echo "G�i l� C�u h�n.";
elseif ($chat == "vua moi hon goi la")
echo "G�i l� T�n h�n.";
elseif ($chat == "hon them cai nua goi la")
echo "G�i l� T�i h�n.";
elseif ($chat == "dang hon ma bi day ra goi la")
echo "G�i l� T� h�n.";
elseif ($chat == "khong cho ma cu hon goi la")
echo "G�i l� �p h�n.";
elseif ($chat == "hen se hon goi la")
echo "G�i l� H�a h�n.";
elseif ($chat == "vua hon goi la")
echo "G�i l� Ho�ng h�n.";
elseif ($chat == "hon chia tay goi la")
echo "G�i l� Ly h�n.";
elseif ($chat == "vua hon vua ngui goi la")
echo "G�i l� V� h�n.";
elseif ($chat == "hon vao khong trung goi la")
echo "G�i l� H�n gi�.";
elseif ($chat == "hon trong mo goi la")
echo "G�i l� H�n ��c.";
elseif ($chat == "hon ma qua som goi la")
echo "G�i l� T�o h�n.";
elseif ($chat == "rat thich hon goi la")
echo "G�i l� K�t h�n.";
elseif ($chat == "hon ma bi hon lai goi la")
echo "G�i l� ��nh th�n.";
elseif ($chat == "when are you leaving")
echo "After 5 minutes I will go";
elseif ($chat == "when will you arrive")
echo "Two more days I will arrive.";
elseif ($chat == "when does the movie start")
echo "7:20 pm movie starts.";
elseif ($chat == "when will he be finished")
echo "Two weeks before he was to be completed.";
elseif ($chat == "when did you cut your hair")
echo "Yesterday I cut my hair";
elseif ($chat == "when are you going to go to university")
echo " Next year I will follow university.";
elseif ($chat == "when will they begin")
echo "Now they will start.";
elseif ($chat == "when did she move to a new apartment")
echo "Three months before she was moved to a new apartment!";
elseif ($chat == "when will you leave england")
echo "Six months, I will leave England.";
elseif ($chat == "when will they buy a new car")
echo "New cars do not know when they will buy.";
elseif ($chat == "me")
echo "What was that?";
elseif ($chat == "sing")
echo "Always look on the bright side of life. No, enough!";
elseif ($chat == "mod")
echo "Would you mind rephrasing that? I think I missed the point.";
elseif ($chat == "golf")
echo "Here is the Golf News from ESPN";
elseif ($chat == "when do you write")
echo "What would you like me to do for you?";
elseif ($chat == "nothing noting nothing")
echo "OK, I hear you.";
elseif ($chat == "nothing")
echo "Okay.";
elseif ($chat == "ave")
echo "Excuse me?";
elseif ($chat == "inaccurate complica")
echo "I'm afraid I didn't quite catch what you said.";
elseif ($chat == "facebook")
echo "It seems I can not call your facebook app, type 'facebook' several times for me to browse the web!";
elseif ($chat == "fine ass")
echo "That was not a very pleasant thing to say.";
elseif ($chat == "where do you like")
echo "Do I have to tell you where? ";
elseif ($chat == "what are you wearing")
echo "I was wearing a multicolored jacket sparkling with sugar black inflammation";
elseif ($chat == "percat, i'm tired")
echo "I advise you to rest";
elseif ($chat == "how�s the weather today")
echo "Do you think it is okay to talk to people you don't know? ";
elseif ($chat == "how�s the weather like today")
echo "What other topics, I do not want to answer";
elseif ($chat == "you are the best assistant ever")
echo "^^! Thanks you !";
elseif ($chat == "you are awesome")
echo "I do not think so";
elseif ($chat == "you�re cool")
echo "ha-h�";
elseif ($chat == "you're beautyful")
echo "Where I am not so beautiful";
elseif ($chat == "you're ugly")
echo "it suits me rather than beautiful";
elseif ($chat == "you're sexy")
echo "slightly too";
elseif ($chat == "you're funny")
echo "gifted by birth but heaven";
elseif ($chat == "siri called you a bit")
echo "I do not like";
elseif ($chat == "who's better, you or siri")
echo "Depending on your";
elseif ($chat == "you�re creepy")
echo "maybe slightly cold";
elseif ($chat == "you're so annoying")
echo "� � � overheating";
elseif ($chat == "i'm drunk")
echo "Drink a glass of lemon has";
elseif ($chat == "how do i look today")
echo "If you are the robots";
elseif ($chat == "may i kiss you")
echo "My father said that pregnant kiss!";
elseif ($chat == "are you hot")
echo "Yes!";
elseif ($chat == "what is love")
echo "Ask your parents";
elseif ($chat == "can you dance")
echo "Sorry, I do not have legs!";
elseif ($chat == "are you real")
echo "No!";
elseif ($chat == "who is your favourite artist")
echo "Cortana and Siri";
elseif ($chat == "i am angry")
echo "I want to cross the water in your chocolate";
elseif ($chat == "talk to me")
echo "I love you!";
elseif ($chat == "you're awesome")
echo "Birds chirping";
elseif ($chat == "what do you eat")
echo "Eating facebook account and your google!";







































































































































































else
echo "Sorry, I do not find, I will open google to assist you!";
?>