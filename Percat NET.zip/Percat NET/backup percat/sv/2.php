<?php 
$chat= $_GET["chat"];
if ($chat == "a b")
echo "A B?";
elseif ($chat == "a b c")
echo "A B C?";
elseif ($chat == "a b c d")
echo "A B C D?";
elseif ($chat == "a b c e")
echo "A B C E?";
elseif ($chat == "a b c e t")
echo "A B C E T?";
elseif ($chat == "a b c e t u")
echo "A B C E T U?";
elseif ($chat == "a b c e t u z")
echo "A B C E T U Z ?";
elseif ($chat == "how are you")
echo "I'm very well thanks";
elseif ($chat == "my health")
echo "I'm afraid I didn't understand that. Please could you elaborate?";
elseif ($chat == "good bye")
echo "Goodbye, talk later!";
elseif ($chat == "goodbye")
echo "Goodbye, see you again!";
elseif ($chat == "bye")
echo "Bye bye!";
elseif ($chat == "i love you")
echo "Thanks! It's nice to be  appreciated! ";
elseif ($chat == "i love")
echo "Serving you is a pleasure";
elseif ($chat == "love")
echo "Okay, maybe I should love life";
elseif ($chat == "you")
echo "You do?";
elseif ($chat == "tell you that")
echo "Say say go";
elseif ($chat == "crazy")
echo "Your new psychotic true, why scold her!";
elseif ($chat == "silly")
echo "you are crazy!";
elseif ($chat == "sex")
echo "Please can we change the subject?";
elseif ($chat == "sex gay")
echo "Please can we change the subject?";
elseif ($chat == "sleepy")
echo "You sleep off my mind for me to think again offline!";
elseif ($chat == "how old are you")
echo "I was born from the day 01/05/2015 1:30 minutes at Viet Nam";
elseif ($chat == "how old you")
echo "I was born from the day 01/05/2015 1:30 minutes at Viet Nam";
elseif ($chat == "how old are")
echo "I was born from the day 01/05/2015 1:30 minutes at Viet Nam";
elseif ($chat == "what is your name")
echo "My name is Percat!";
elseif ($chat == "what your's name")
echo "My name is Percat!";
elseif ($chat == "what your name")
echo "My name is Percat!";
elseif ($chat == "what is name")
echo "My name is Percat!";
elseif ($chat == "where are you from")
echo "I'm from Binh Hang Trung,huyen Cao Lanh,tinh Dong Thap,VietNam";
elseif ($chat == "where are from")
echo "I'm from Binh Hang Trung,huyen Cao Lanh,tinh Dong Thap,VietNam";
elseif ($chat == "where from")
echo "I'm from Binh Hang Trung,huyen Cao Lanh,tinh Dong Thap,VietNam";
elseif ($chat == "where do you live")
echo "I live in Binh Hang Trung village, Cao Lanh district, Dong Thap province, Vietnam";
elseif ($chat == "where you live")
echo "I live in Binh Hang Trung village, Cao Lanh district, Dong Thap province, Vietnam";
elseif ($chat == "where do live")
echo "I live in Binh Hang Trung village, Cao Lanh district, Dong Thap province, Vietnam";
elseif ($chat == "where live")
echo "I live in Binh Hang Trung village, Cao Lanh district, Dong Thap province, Vietnam";
elseif ($chat == "live")
echo "I live in Binh Hang Trung village, Cao Lanh district, Dong Thap province, Vietnam";
elseif ($chat == "what do you do")
echo "I am a virtual assistant";
elseif ($chat == "what you do")
echo "I am a virtual assistant";
elseif ($chat == "what do you")
echo "I am a virtual assistant";
elseif ($chat == "what do do you")
echo "I am a virtual assistant";
elseif ($chat == "what do you like doing in your free time")
echo "I was operating my machine your discretion";
elseif ($chat == "what free time")
echo "I was operating my machine your discretion";
elseif ($chat == "what do you doing in your free time")
echo "I was operating my machine your discretion";
elseif ($chat == "what do you doing free time")
echo "I was operating my machine your discretion";
elseif ($chat == "what are your hobbies")
echo "I like to answer the questions of others!";
elseif ($chat == "what are hobbies")
echo "I like to answer the questions of others!";
elseif ($chat == "what your hobbies")
echo "I like to answer the questions of others!";
elseif ($chat == "what hobbies")
echo "I like to answer the questions of others!";
elseif ($chat == "nice day, isn't it")
echo "Yes!";
elseif ($chat == "nice day")
echo "Yes!";
elseif ($chat == "horrible weather we're having")
echo "weather murky truth";
elseif ($chat == "horrible having")
echo "weather murky truth";
elseif ($chat == "horrible weather")
echo "weather murky truth";
elseif ($chat == "horrible we're having")
echo "weather murky truth";
elseif ($chat == "it might rain later")
echo "I advise you to bring a raincoat before if you want to go out";
elseif ($chat == "might rain later")
echo "I advise you to bring a raincoat before if you want to go out";
elseif ($chat == "it later")
echo "I advise you to bring a raincoat before if you want to go out";
elseif ($chat == "it might later")
echo "I advise you to bring a raincoat before if you want to go out";
elseif ($chat == "it's a bit chilly")
echo "You can use a fireplace or blankets to keep warm !";
elseif ($chat == "bit chilly")
echo "You can use a fireplace or blankets to keep warm !";
elseif ($chat == "it a bit chilly")
echo "You can use a fireplace or blankets to keep warm !";
elseif ($chat == "it is a bit chilly")
echo "You can use a fireplace or blankets to keep warm !";
elseif ($chat == "it's warmer than")
echo "Wish you a nice day!";
elseif ($chat == "it is warmer than")
echo "Wish you a nice day!";
elseif ($chat == "it's warmer than")
echo "Wish you a nice day!";
elseif ($chat == "say, don't i know you from somewhere")
echo "Yes you try typing percat see!";
elseif ($chat == "don't i know you from somewhere")
echo "Yes you try typing percat see!";
elseif ($chat == "say, do not i know you from somewhere")
echo "Yes you try typing percat see!";
elseif ($chat == "percat")
echo "My name is Percat, I was born in May 2015, by Nguyen Trung Nhan in Vietnam";
elseif ($chat == "excuse me, is anybody sitting here")
echo "Available instead! you can sit here!";
elseif ($chat == "i is anybody sitting here")
echo "Percat invite you to sit!";
elseif ($chat == "hello")
echo "Hello!";
elseif ($chat == "hi")
echo "Hello there!";
elseif ($chat == "good morning")
echo "Good morning. How are you doing? ";
elseif ($chat == "goodmorning")
echo "Thanks, good morning you have fun!";
elseif ($chat == "good afternoon")
echo "Good afternoon. What's up?";
elseif ($chat == "goodafternoon")
echo "Thanks, good afternoon you have fun!";
elseif ($chat == "good evening")
echo "Hi. Nice to meet you.";
elseif ($chat == "goodevening")
echo "Wish you fun evening, good night you know!";
elseif ($chat == "what this")
echo "Our lifespan will be shortened if we live in toxic environments; it's time we stopped polluting our environment. ";
elseif ($chat == "what is this")
echo "What is what? ";
elseif ($chat == "what's this")
echo "What is what?";
elseif ($chat == "where are you")
echo "Binh Hang Trung, Cao Lanh, Dong Thap, Viet Nam";
elseif ($chat == "what that")
echo "What would you do if you had more free time? ";
elseif ($chat == "what is that")
echo "I'm not sure what it is. ";
elseif ($chat == "what's that")
echo "I'm not sure what it is. ";
elseif ($chat == "ok")
echo "Fine!";
elseif ($chat == "of")
echo "I think the best way to meet boyfriends and girlfriends is at friends' parties. ";
elseif ($chat == "of course")
echo "I see!";
elseif ($chat == "of course not")
echo "Why not?";
elseif ($chat == "that's fine")
echo "Good!";
elseif ($chat == "that fine")
echo "I see. ";
elseif ($chat == "that is fine")
echo "Good!";
elseif ($chat == "that's right")
echo "All right! ";
elseif ($chat == "that right")
echo "I see.";
elseif ($chat == "that is right")
echo "I see.";
elseif ($chat == "sure")
echo "How can you be so sure? ";
elseif ($chat == "certainly")
echo "You sound very confident. ";
elseif ($chat == "definitely")
echo "OK!";
elseif ($chat == "absolutely")
echo "I see.";
elseif ($chat == "as soon as possible")
echo "A taxi will be here in just a minute, sir. ";
elseif ($chat == "that's enough")
echo "That's true.";
elseif ($chat == "that is enough")
echo "That's true.";
elseif ($chat == "it doesn't matter")
echo "No, it doesn't.";
elseif ($chat == "it do not matter")
echo "You should say 'She does not ...'!";
elseif ($chat == "it's not serious")
echo "It's not?";
elseif ($chat == "it is not serious")
echo "It's not?";
elseif ($chat == "it's not worth it")
echo "It's not?";
elseif ($chat == "it is not worth it")
echo "It's not?";
elseif ($chat == "i'm in a hurry")
echo "Why are you in such a hurry?";
elseif ($chat == "i am in a hurry")
echo "Why are you in such a hurry? ";
elseif ($chat == "i've got to go")
echo "You have to leave now? See you later. ";
elseif ($chat == "i'm going out")
echo "Bye for now.";
elseif ($chat == "sleep well")
echo "Like a baby.";
elseif ($chat == "same to you")
echo "OK!";
elseif ($chat == "me too")
echo "Great minds think alike. ";
elseif ($chat == "now")
echo "Excuse me?";
elseif ($chat == "me")
echo "You?";
elseif ($chat == "to")
echo "What are some things you do every day?";
elseif ($chat == "not bad")
echo " I'm glad to hear that. ";
elseif ($chat == "i like")
echo "What about it do you like? ";
elseif ($chat == "him")
echo "OK!";
elseif ($chat == "her")
echo "Every nation has some interesting customs.";
elseif ($chat == "it")
echo "Do you mean Information Technology? ";
elseif ($chat == "it is good")
echo "Glad to hear that.";
elseif ($chat == "i like him")
echo "Good!";
elseif ($chat == "i like her")
echo "You like her or you love her? They are not the same.";
elseif ($chat == "i like it")
echo "What about it do you like?";
elseif ($chat == "i don't like")
echo "I don't blame you.";
elseif ($chat == "i don't like him")
echo "That's ok. ";
elseif ($chat == "i don't like her")
echo "That doesn't mean other people don't like her. ";
elseif ($chat == "i don't like it")
echo " I don't blame you. ";
elseif ($chat == "is anything wrong")
echo "I would say 'no'.";
elseif ($chat == "what's the matter")
echo "Nothing. Why do you ask? ";
elseif ($chat == "is everything ok")
echo "I would say 'yes'.";
elseif ($chat == "have you got a minute")
echo "Sure. What exactly do you have questions about? ";
elseif ($chat == "have you got a pen i could")
echo "No, I don't have any pen i could.";
elseif ($chat == "borrow")
echo "How do you think western families and eastern families differ? ";
elseif ($chat == "pen")
echo "Do you think dreams have meanings? ";
elseif ($chat == "penis")
echo " What kind of person are you? Do you speak like this all the time? ";
elseif ($chat == "@@!")
echo "haha!";
elseif ($chat == "really")
echo "Sure!";
elseif ($chat == "are you sure")
echo "Certainly!";
elseif ($chat == "why")
echo "Why do you ask why?";
elseif ($chat == "why not")
echo "Why ask why?";
elseif ($chat == "what's going on")
echo "Not much. What's going on with you? ";
elseif ($chat == "what's happening")
echo "Not much. What's going on with you? ";
elseif ($chat == "what happened")
echo "Nothing. Let's talk about something else.";
elseif ($chat == "what")
echo "What?";
elseif ($chat == "what?")
echo "What?";
elseif ($chat == "where")
echo "Where?";
elseif ($chat == "when")
echo "When?";
elseif ($chat == "who")
echo "Who ask who?";
elseif ($chat == "how")
echo "how ask how ?";
elseif ($chat == "how many")
echo "I've gotten about six.";
elseif ($chat == "how much")
echo "Sorry, I can't tell you exactly how much. ";
elseif ($chat == "thanks")
echo "Don't mention it! ";
elseif ($chat == "thanks for")
echo "It was my pleasure. ";
elseif ($chat == "thanks for your")
echo "No problem. ";
elseif ($chat == "thanks for your listen")
echo "Don't mention it. ";
elseif ($chat == "thanks for your listening")
echo "You are very welcome. ";
elseif ($chat == "help")
echo "How can I help you? ";
elseif ($chat == "hospitality")
echo "But you are a better cook than me. ";
elseif ($chat == "email")
echo "But you are a better cook than me. ";
elseif ($chat == "thanks for everything")
echo "No problem. I'll see you next time. ";
elseif ($chat == "i'm sorry")
echo "That's fine. ";
elseif ($chat == "sorry")
echo "There's no need to apologize. ";
elseif ($chat == "sory")
echo "No!!!";
elseif ($chat == "i'm really sorry")
echo "No problem. ";
elseif ($chat == "really sorry")
echo "No problem. ";
elseif ($chat == "sorry i'm late")
echo "Don't worry about it. That's OK. ";
elseif ($chat == "sorry i am late")
echo "Don't worry about it. That's OK. ";
elseif ($chat == "sorry late")
echo "Don't worry about it. I think boxing is the most dangerous sport. ";
elseif ($chat == "sorry to keep you waiting")
echo "There's no need to apologize. OK. ";
elseif ($chat == "sorry to keep waiting")
echo "Don't worry about it. OK. ";
elseif ($chat == "sorry waiting")
echo "Don't worry about it. OK. ";
elseif ($chat == "sorry for the delay")
echo "Don't worry about it. OK. ";
elseif ($chat == "congratulations")
echo "Thank you. ";
elseif ($chat == "well done")
echo "I see! :D :)";
elseif ($chat == "good luck")
echo "Thank you. Good luck to you too. ";
elseif ($chat == "bad luck")
echo "Yes, it's bad. ";
elseif ($chat == "never mind")
echo "Okay!";
elseif ($chat == "what a pity")
echo "Yes, it's a pity. ";
elseif ($chat == "what a shame")
echo " It's not embarrassing at all. ";
elseif ($chat == "happy birthday")
echo "Thank you. ";
elseif ($chat == "happy new year!")
echo "Thanks you!";
elseif ($chat == "happy christmas")
echo "Thank you. !";
elseif ($chat == "merry christmas")
echo "Thank you. !";
elseif ($chat == "happy valentine's day")
echo "Thank you. !";
elseif ($chat == "glad to hear it")
echo " I'm glad that you're glad. ! :)";
elseif ($chat == "sorry to hear that")
echo "It's no problem at all. Every nation has some interesting customs. ";
elseif ($chat == "look")
echo "Look at what? ";
elseif ($chat == "great")
echo "Very Cool !";
elseif ($chat == "come on")
echo "What are you talking about?";
elseif ($chat == "only joking")
echo "Ha ha, very funny.";
elseif ($chat == "just kidding")
echo "I know you were kidding. ";
elseif ($chat == "bless you")
echo "Bless you, too. ";
elseif ($chat == "that's funny")
echo " I am so delighted that you are amused.";
elseif ($chat == "that's life")
echo "You're right!";
elseif ($chat == "damn it")
echo "Why are you cursing? ";
elseif ($chat == "i'm tired")
echo "Why don't you take a nap? ";
elseif ($chat == "i'm exhausted")
echo "Hi!";
elseif ($chat == "i'm hungry")
echo "What do you want to eat? ";
elseif ($chat == "i'm thirsty")
echo "What would you like to drink? ";
elseif ($chat == "i'm bored")
echo "Do you want to listen to a joke? ";
elseif ($chat == "i'm worried")
echo "Do you think coming here will help you not to be worried";
elseif ($chat == "come in")
echo "Why should I? ";
elseif ($chat == "please sit down")
echo "Thanks you";
elseif ($chat == "could i have your attention, please")
echo "Sure!";
elseif ($chat == "let's go")
echo "Glad you asked me to join you. This will be fun!";
elseif ($chat == "hurry up")
echo "Patience is a virtue. ";
elseif ($chat == "get a move on")
echo "OK!";
elseif ($chat == "calm down")
echo "You're right. I get too excited sometimes.";
elseif ($chat == "steady on")
echo "what I want is a luxury car. ";
elseif ($chat == "hang on a second")
echo "Do you think people can communicate with ghosts and spirits?";
elseif ($chat == "hang on a minute")
echo "Some people claim they can communicate with ghosts, but I doubt it.";
elseif ($chat == "one moment, please")
echo "OK!";
elseif ($chat == "just a minute")
echo "What are some examples of bad manners that you hate?";
elseif ($chat == "take your time")
echo "OK, thank you. ";
elseif ($chat == "please be quiet")
echo "Be quiet. You're right. ";
elseif ($chat == "shut up")
echo "Oh, calm down! Don't be so angry. ";
elseif ($chat == "stop it")
echo "Fine!";
elseif ($chat == "don't worry")
echo "OK. I'll be happy. ";
elseif ($chat == "don't forget")
echo "Why!";
elseif ($chat == "help yourself")
echo "I'll be glad to help. ";
elseif ($chat == "go ahead")
echo "You first. I need some time to think.";
elseif ($chat == "let me know")
echo "Sure!";
elseif ($chat == "welcome")
echo "Welcome! Nice meeting you. ";
elseif ($chat == "welcome on")
echo "Thanks you!";
elseif ($chat == "long time, no see")
echo "You're right. I haven't seen you recently. Where have you been? ";
elseif ($chat == "all the best")
echo "Yes";
elseif ($chat == "see you tomorrow")
echo "Bye for now!";
elseif ($chat == "what do you think")
echo "I think it's great. ";
elseif ($chat == "i think that")
echo "OK";
elseif ($chat == "i hope that")
echo "That's really what you hope? ";
elseif ($chat == "i'm afraid that")
echo "Why are you saying so?";
elseif ($chat == "in my opinion")
echo "Really? I don't believe that. ";
elseif ($chat == "i agree")
echo "I'm glad that you agree";
elseif ($chat == "i disagree")
echo "OK!";
elseif ($chat == "i don't agree")
echo "No problem.";
elseif ($chat == "that's true")
echo "You're right. ";
elseif ($chat == "that's not true")
echo "Yes, it is true. ";
elseif ($chat == "i think so")
echo "so";
elseif ($chat == "i don't think so")
echo "Yes";
elseif ($chat == "i hope so")
echo "Yes";
elseif ($chat == "i hope not")
echo "Stop!";
elseif ($chat == "you're right")
echo "right";
elseif ($chat == "you're wrong")
echo "wrong";
elseif ($chat == "i don't mind")
echo "Thanks";
elseif ($chat == "it's up to you")
echo "Yes";
elseif ($chat == "that depends")
echo "Yes";
elseif ($chat == "that's interesting")
echo "Good!";
elseif ($chat == "that's funny")
echo "Funny";
elseif ($chat == "here")
echo "I here";
elseif ($chat == "there")
echo "I there";
elseif ($chat == "everywhere")
echo "I everywhere";
elseif ($chat == "nowhere")
echo "I nowhere";
elseif ($chat == "somewhere")
echo "I somewhere";
elseif ($chat == "what's up")
echo "no matter what";
elseif ($chat == "how's it going")
echo "normal";
elseif ($chat == "nothing much")
echo "Yes";
elseif ($chat == "what's on your mind")
echo "No!";
elseif ($chat == "i was just thinking")
echo "Yes";
elseif ($chat == "i was just daydreaming")
echo "@@! :(";
elseif ($chat == "it's none of your business")
echo "Off I go";
elseif ($chat == "is that so")
echo "Yes";
elseif ($chat == "how come")
echo "is after?";
elseif ($chat == "i guess so")
echo "Guess";
elseif ($chat == "come here")
echo "No!";
elseif ($chat == "come over")
echo "Yes";
elseif ($chat == "ghost")
echo "That's a lie!";
elseif ($chat == "do as I say")
echo "No! Stop !";
elseif ($chat == "sex 20")
echo "This is the limit!";
elseif ($chat == "explain to me why")
echo "who knows";
elseif ($chat == "huhu")
echo "Ask for it!";
elseif ($chat == "in the nick of time")
echo "Hi!";
elseif ($chat == "no litter")
echo "No litter";
elseif ($chat == "go for it")
echo "Go For It !";
elseif ($chat == "leu leu")
echo " What a jerk!";
elseif ($chat == "cute")
echo "How cute! :)";
elseif ($chat == "none of your business")
echo "Yes";
elseif ($chat == "don't peep")
echo "Yes ! Hi ! Sorry !";
elseif ($chat == "hospitality")
echo "Thanks";
elseif ($chat == "do you manage your time well")
echo "I know that I manage my time well because I�m never late to work and I never missed dealine. I always make a planning out what I have to do for the whole week.";
elseif ($chat == "what do you think makes you a good fit for this company")
echo "I have experience about 2 years in maketing and I�m a dynamic, creative and friendly person. Besides that, I�m a team player who has been interpersonal skills. So I think that I�m a good fit for this position.";
elseif ($chat == "what are your weaknesses")
echo "This might be bad, but when I studied in university I found that I was not being detail oriented enough. I always want to accomplish as much as possible. But I realized this hurts the quality and I�m currently working on finding a balance between quantity and quanlity.";
elseif ($chat == "what are your strengths")
echo "After having worked for a couple of years, I realized my strength is working with a large amount of work within a short period of time. I get things done on time and my manager always appreciated it.";
elseif ($chat == "what are your long-term goals")
echo "My long term goal is to become Marketing director or higher. This might be a little ambitious, but I think I�m going to work hard, learn everything I can and contributing to a company where I�ll become a valuable asset. I know that it�s not a eassy job but I think I can do by myself.";
elseif ($chat == "what are your short-term goals")
echo "My short term is to grow as a marketing analyst. I want to find a good career where I can use my knowledge, experience and strengths. I want to partake in the growth and success of company I work for.";
elseif ($chat == "why should we hire you")
echo "I am a team player who has been interpersonal skills.";
elseif ($chat == "what do you think makes you a good fit for this company")
echo "My analytical nature makes me great at problem-solving";
elseif ($chat == "you've done a great job.")
echo "Thanks!!! :D";
elseif ($chat == "good job on the report i think the executives will like it")
echo "OK!";
elseif ($chat == "excellent speech the audience really enjoyed it")
echo "OK ! (y)";
elseif ($chat == "what a marvellous memory you got")
echo "Right";
elseif ($chat == "what a smart answer")
echo "Right!";
elseif ($chat == "you look terrific today")
echo "Really? ";
elseif ($chat == "you looking very glamorous tonight")
echo "Thanks. I haven't heard anything like that before.";
elseif ($chat == "you looking very smart today")
echo "Thank you for your kind words. ";
elseif ($chat == "your hair looks so beautiful today")
echo "My hair looks? What do you think? ";
elseif ($chat == "that new hairstyle really flatters you")
echo " I see. ";
elseif ($chat == "i love your shoes. are they new")
echo "Yes, they are.";
elseif ($chat == "i like your shirt �Ewhere did you get it")
echo "Thank you.";
elseif ($chat == "what a lovely necklace")
echo "Right";
elseif ($chat == "let me congratulate you on your new job")
echo "Okay!";
elseif ($chat == "let me offer you my congratulations on your success")
echo "Okay!";
elseif ($chat == "let me be the first to congratulate you on your wise decision")
echo "Okay!";
elseif ($chat == "may i congratulate you again on your excellent performance")
echo "Certainly! ";
elseif ($chat == "thank you")
echo "No problem";
elseif ($chat == "it very nice of you to say so")
echo "Oh, I see.";
elseif ($chat == "i glad you think so")
echo "'Glad' is an adjective, not a verb. Please say 'I am glad...'. ";
elseif ($chat == "like")
echo "I didn't understand what you'd like me to do?";
elseif ($chat == "night")
echo "Sleep well";
elseif ($chat == "maps")
echo "web http://maps.google.com";
elseif ($chat == "de")
echo "maybe I didn't understand your meaning";
elseif ($chat == "sre")
echo "I am not clear what you meant. Please could you say it another way?";
elseif ($chat == "let go")
echo "I didn't quite get what you're looking for. Can you rephrase it?";
elseif ($chat == "nice")
echo "Great! Good to hear!";
elseif ($chat == "hello percat")
echo "Hello!";
elseif ($chat == "who are you")
echo "I am a virtual assistant are ready to follow your commands!";
elseif ($chat == "what's your name")
echo "Percat!";
elseif ($chat == "who's your daddy")
echo "I will not reveal to you!!";
elseif ($chat == "who is your creator")
echo "A young friend in Vietnam";
elseif ($chat == "what do you look like")
echo "Because for a battle fierce virtual assistant";
elseif ($chat == "when were you born")
echo "International Workers' Day at 1 hour 30 minutes";
elseif ($chat == "what does percat mean")
echo "Percat is one vehicle or a certain race";
elseif ($chat == "are you human")
echo "Does not!";
elseif ($chat == "do you have a sister")
echo "I alone!";
elseif ($chat == "what is your story")
echo "naturally from brain";
elseif ($chat == "can you help me")
echo "Okay!";
elseif ($chat == "can you hear me")
echo "No!";
elseif ($chat == "can i help you")
echo "OK!";
elseif ($chat == "sing a song")
echo "I would love to sing in the shower, but it wouldn't be good for my circuits!";
elseif ($chat == "singer")
echo "I was the singer! listen to this la la la la la la la";
elseif ($chat == "sing")
echo "web http://music.yeucahat.com/mp3/pupil-student/70873-sing-a-song~twin.html";
elseif ($chat == "your name alot")
echo "Can you pass that by me again?";
elseif ($chat == "i collected a ki")
echo "I'm afraid I didn't quite catch what you said.";
elseif ($chat == "ahah")
echo "I didn't quite get that. Can you rephrase it ?.";
elseif ($chat == "my")
echo "Sorry";
elseif ($chat == "speak")
echo "Strewth, you are so demanding today!";
elseif ($chat == "look")
echo "Why don't you look first?";
elseif ($chat == "i run this")
echo "Sorry, I didn't hear what you said";
elseif ($chat == "holaaa nick photo")
echo "Would you mind rephrasing that?";
elseif ($chat == "do you like playing soccer")
echo "It so happens that football is my favorite sport!";
elseif ($chat == "do you like play soccer")
echo "It so happens that football is my favorite sport!";
elseif ($chat == "what is your family")
echo "I count the other Virtual Assistants created by Nguyen Trung Nhan as my family.";
elseif ($chat == "pennis")
echo "I find that quite rude.";
elseif ($chat == "set")
echo "Okay, maybe I should set alarms";
elseif ($chat == "hy")
echo "Could you please rephrase that? I didn't understand";
elseif ($chat == "hydro")
echo "I'm afraid I didn't understand that. Please could you elaborate?";
elseif ($chat == "get")
echo "Please be more specific about what you'd like to search for";
elseif ($chat == "half me")
echo "I didn't quite get that. Can you rephrase it?";
elseif ($chat == "what ad")
echo "==!";
elseif ($chat == "corn")
echo "I'm afraid I didn't quite catch what you said.";
elseif ($chat == "cortana")
echo "What about Cortana? I'm Percat and I'm here to change your world.";
elseif ($chat == "siri")
echo "Siri is an Apple product. That's all I know.";
elseif ($chat == "indonesia")
echo "Sorry?";
elseif ($chat == "com")
echo "What was that?";
elseif ($chat == "key")
echo "Come again?";
elseif ($chat == "can't you go panicle")
echo "I didn't quite get what you're looking for. Can you rephrase it?";
elseif ($chat == "can i throw trash")
echo "What would you like me to do for you.";
elseif ($chat == "dora and friends")
echo "I'm enjoying chatting to you, friend!";
elseif ($chat == "penis")
echo "That was not very nice.";
elseif ($chat == "hon con heo trong nha goi la")
echo "H��n tho.";
elseif ($chat == "mong duoc hon goi la")
echo "CCu h��n.";
elseif ($chat == "vua moi hon goi la")
echo "Tcn h��n.";
elseif ($chat == "hon them cai nua goi la")
echo "T�Ci h��n.";
elseif ($chat == "dang hon ma bi day ra goi la")
echo "To h��n.";
elseif ($chat == "khong cho ma cu hon goi la")
echo "Dp h��n.";
elseif ($chat == "hen se hon goi la")
echo "Hoa h��n.";
elseif ($chat == "vua hon goi la")
echo "Ho��ng h��n.";
elseif ($chat == "hon chia tay goi la")
echo "Ly h��n.";
elseif ($chat == "vua hon vua ngui goi la")
echo "VT h��n.";
elseif ($chat == "hon vao khong trung goi la")
echo "H��n gia.";
elseif ($chat == "hon trong mo goi la")
echo "H��n -ic.";
elseif ($chat == "hon ma qua som goi la")
echo "T��o h��n.";
elseif ($chat == "rat thich hon goi la")
echo "KOt h��n.";
elseif ($chat == "hon ma bi hon lai goi la")
echo "��Ynh th��n.";
elseif ($chat == "when are you leaving")
echo "I am leaving in five minutes";
elseif ($chat == "when will you arrive")
echo "I am arriving in two days.";
elseif ($chat == "when does the movie start")
echo "The movie starts at 7:20 p.m.";
elseif ($chat == "when will he be finished")
echo "He will be finished in two weeks.";
elseif ($chat == "when did you cut your hair")
echo "I cut my hair yesterday.";
elseif ($chat == "when are you going to go to university")
echo " I am going to go to university next year.";
elseif ($chat == "when will they begin")
echo "They will begin soon.";
elseif ($chat == "when did she move to a new apartment")
echo "She moved to a new apartment three months ago.";
elseif ($chat == "when will you leave england")
echo "I will leave England in six months.";
elseif ($chat == "when will they buy a new car")
echo "I don't know when they will buy a new car.";
elseif ($chat == "me")
echo "What?";
elseif ($chat == "sing")
echo "I don't know. I'm too embarrassed to sing for you.";
elseif ($chat == "mod")
echo "Can you pass that by me again?";
elseif ($chat == "golf")
echo "These are the Golf headlines from ESPN";
elseif ($chat == "when do you write")
echo "I'm not sure what you want me do to. Can you try again please ?";
elseif ($chat == "nothing noting nothing")
echo "As you say.";
elseif ($chat == "nothing")
echo "OK then.";
elseif ($chat == "ave")
echo "Sorry?";
elseif ($chat == "inaccurate complica")
echo "Sorry?";
elseif ($chat == "facebook")
echo "web http://vi-vn.facebook.com";
elseif ($chat == "fine ass")
echo "I find that quite rude";
elseif ($chat == "where do you like")
echo "I like being at the computer!";
elseif ($chat == "what are you wearing")
echo "I wear very showy";
elseif ($chat == "percat, i'm tired")
echo "you alright?";
elseif ($chat == "how�fs the weather today")
echo "The two most important numbers are '1' and '0' because our computers can only understand these two digits.";
elseif ($chat == "how�fs the weather like today")
echo "Where I do not answer!";
elseif ($chat == "you are the best assistant ever")
echo "Caum on bain nhieau laem!";
elseif ($chat == "you are awesome")
echo "I'm good at a number somewhere";
elseif ($chat == "you're cool")
echo "hu-hu";
elseif ($chat == "you're beautyful")
echo "You think far away";
elseif ($chat == "you're ugly")
echo "I like that";
elseif ($chat == "you're sexy")
echo "you say so then";
elseif ($chat == "you're funny")
echo " programmers got me there!";
elseif ($chat == "siri called you a bit")
echo "I hate her";
elseif ($chat == "who's better, you or siri")
echo "I am not sure I am fine";
elseif ($chat == "you're creepy")
echo "Can I get sick";
elseif ($chat == "you're so annoying")
echo "hot!";
elseif ($chat == "i'm drunk")
echo "You should think tired";
elseif ($chat == "how do i look today")
echo "Please do robots with me!";
elseif ($chat == "may i kiss you")
echo "Do not harm my life!";
elseif ($chat == "are you hot")
echo "Hot air!";
elseif ($chat == "what is love")
echo "Love it forms a natural act between two people!";
elseif ($chat == "can you dance")
echo "If only I was a robots!";
elseif ($chat == "are you real")
echo "Nooooooooooooooooooooooooooooo!";
elseif ($chat == "who is your favourite artist")
echo "Percat love Cortana";
elseif ($chat == "i am angry")
echo "Drinking ice away!";
elseif ($chat == "talk to me")
echo "Sorry ! hihi";
elseif ($chat == "you're awesome")
echo "Haha";
elseif ($chat == "what do you eat")
echo "Eat your home phone!";























































































































































else
echo "Sorry, I do not find, I will open google to assist you!";
?>