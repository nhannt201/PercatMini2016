﻿<?php 
$chat= $_GET["chat"];
if ($chat == "a b")
echo "A B?";
elseif ($chat == "a b c")
echo "A B C?";
elseif ($chat == "a b c d")
echo "A B C D?";
elseif ($chat == "a b c e")
echo "A B C E?";
elseif ($chat == "a b c e t")
echo "A B C E T?";
elseif ($chat == "a b c e t u")
echo "A B C E T U?";
elseif ($chat == "a b c e t u z")
echo "A B C E T U Z ?";
elseif ($chat == "xin chào")
echo "Chào bạn!";
elseif ($chat == "chào")
echo "Chào!";
elseif ($chat == "sex")
echo "Chúng ta có thể chuyển sang chủ đề khác!";
elseif ($chat == "2")
echo "Chào!";
elseif ($chat == "bạn tên là gì")
echo "Tôi là Percat!";
elseif ($chat == "bạn từ đâu đến")
echo "Tôi đến từ Việt Nam xã Bình Hàng Trung, huyện Cao Lãnh, tỉnh Đồng Tháp!";
elseif ($chat == "bạn mấy tuổi")
echo "Tôi được sinh ra vào ngày 28.5.2015 lúc 8:45 phút!";
elseif ($chat == "tôi yêu bạn")
echo "Tôi cũng thế!";
elseif ($chat == "tôi đói bụng")
echo "Bạn có thể ăn một gói mì tôm hay tô bún bò!";
elseif ($chat == "chào buổi sáng")
echo "Chào buổi sáng ! Chúc bạn một ngày mới vui vẻ!";
elseif ($chat == "chào sáng")
echo "Sáng vui vẻ !";
elseif ($chat == "đi chết đi")
echo "Vậy thì hai chúng ta cùng chết !";
elseif ($chat == "hát đi")
echo "Tôi hát được cũng đã hát rồi !";
elseif ($chat == "đồ tâm thần")
echo "đồ điên , tửng max cà chớn !";
elseif ($chat == "khùng")
echo "tại sao chửi mình !";
elseif ($chat == "tạm biệt")
echo "Hẹn gặp lại !";
elseif ($chat == "buồn quá")
echo "Con cò nó cắn con chim đứt con sâu";
elseif ($chat == "max")
echo "Ai max ??? Bạn bị Max à tôi chuồn trước đây";
elseif ($chat == "sắp tới tận thế")
echo "Trốn đi!";
elseif ($chat == "tận thế")
echo "Tôi là cổ máy chắc không biết gì nhiều";
elseif ($chat == "percat")
echo "Tôi tên là Percat được sinh vào lúc 8:45 phút bởi Nguyễn Trung Nhẫn tại Đồng Tháp, Việt Nam";
elseif ($chat == "khỏe không")
echo "không khỏe";
elseif ($chat == "bạn khỏe không")
echo "không";
elseif ($chat == "bạn có khỏe không")
echo "Vâng, Tôi rất là khỏe, khỏe ơi là khỏe mà chắc tôi khỏe :3";
elseif ($chat == "tình yêu là cái gì")
echo "Là tình yêu lên google hay bing hoặc yahoo ở dưới tìm đi !";
elseif ($chat == "ma kìa")
echo "Đâu ! tôi không thấy";
elseif ($chat == "dm")
echo "Đỉ bạn !";
elseif ($chat == "")
echo "Mình không hiểu ý bạn";
else
echo "error";
?>