﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock
Imports System.IO
Imports System.Net
Public Class pc

    Dim Time As String



    Private Sub pc_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Dim a As String
            Dim u As String

            a = getUrlSource("http://percat.esy.es/ip.php")

            u = getUrlSource("http://percat.esy.es/user/" & a & ".txt")

            If u = "no" Then
                Timer1.Enabled = True
                so.Text = "1"
            Else
                Timer1.Enabled = False
                so.Text = "1"
                n1.Enabled = True
                bing.Visible = False
                google.Visible = False
                yahoo.Visible = False
            End If
            'sw.Navigate("http://translate.google.com/translate_tts?tl=en&q=what is yor name")

        Catch
            Timer1.Enabled = True
            so.Text = "1"
        End Try
    End Sub




    Private Sub ten_MouseClick(sender As Object, e As MouseEventArgs) Handles ten.MouseClick
        ten.Text = ""
    End Sub

    Public Function getUrlSource(url As String) As String
        Dim Request As HttpWebRequest = HttpWebRequest.Create(url)
        Dim Response As HttpWebResponse = Request.GetResponse()
        Dim reader As StreamReader = New StreamReader(Response.GetResponseStream)
        Dim httpContent As String
        httpContent = reader.ReadToEnd
        Return httpContent
    End Function

    Private Sub bt1_Click(sender As Object, e As EventArgs) Handles bt1.Click
        Dim bd As String
        percat2.Image = a.d2.Image
        en.Text = "Hello, " & ten.Text
        vi.Text = "Xin chào, " & ten.Text
        bd = getUrlSource("http://percat.esy.es/get.php?name=" & ten.Text)
        '  Debug.Print(GoogleSpeak("Hello ," & ten.Text, "en", True))
        '   wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & "Hello ," & ten.Text
        Dim SAPI
        SAPI = CreateObject("SAPI.spvoice")

        SAPI.Speak("Hello ," & ten.Text)
        percat2.Image = a.d1.Image
        chat.Visible = True
        send.Visible = True
        ten.Visible = False
        bt1.Visible = False
    End Sub


    Private Sub n1_Tick(sender As Object, e As EventArgs) Handles n1.Tick
        Dim yx As String
        Dim u As String
        Dim a1 As String
        Dim er As String


        er = getUrlSource("http://percat.esy.es/wel.txt")

       
        a1 = getUrlSource("http://percat.esy.es/ip.php")
  
        u = getUrlSource("http://percat.esy.es/user/" & a1 & ".txt")
        percat2.Image = a.d2.Image
        en.Text = "Hello, " & u
        vi.Text = "Xin chào, " & u
        '   wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & "Hello ," & u
        Dim SAPI
        SAPI = CreateObject("SAPI.spvoice")

        SAPI.Speak("Hello ," & u)
        percat2.Image = a.d1.Image
        chat.Visible = True
        send.Visible = True
        percat2.Enabled = True
        percat2.Image = a.d4.Image
        yx = er
        '  wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & er
        Dim SAPI2
        SAPI2 = CreateObject("SAPI.spvoice")

        SAPI2.Speak(er)
        percat2.Image = a.d1.Image
        n1.Enabled = False
    End Sub



    Private Sub send_Click(sender As Object, e As EventArgs) Handles send.Click
        sa.Text = Int(Rnd() * 2)
        Try

            If sa.Text = "0" Then
                q1.Enabled = True
                sss.Enabled = False
            ElseIf sa.Text = "1" Then
                q2.Enabled = True
                sss.Enabled = False
            End If
            sss.Enabled = False
        Catch
            sss.Enabled = False
        End Try
        Label1.Visible = True
    End Sub

    Private Sub sss_Tick(sender As Object, e As EventArgs) Handles sss.Tick
        Try

            If sa.Text = "0" Then
                q1.Enabled = True
                sss.Enabled = False
            ElseIf sa.Text = "1" Then
                q2.Enabled = True
                sss.Enabled = False
            End If
            sss.Enabled = False
        Catch
            sss.Enabled = False
        End Try
    End Sub

    Private Sub q1_Tick(sender As Object, e As EventArgs) Handles q1.Tick
        nnt.Enabled = True
        ttt.Text = chat.Text

        ' neu rong
        If chat.Text = "" Then
            ct.Text = "You did not enter content!"
            ' wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & "You did not enter content!"
            Dim SAPI
            SAPI = CreateObject("SAPI.spvoice")

            SAPI.Speak("You did not enter content!")
            en.Text = ct.Text
            vi.Text = "Bạn chưa nhập nội dung!"

            ' duyet am thanh
        ElseIf InStr(chat.Text, "speak") > 0 Then
            chat.Text = Replace(chat.Text, "speak", "")
            Dim do1i1 As String
            do1i1 = chat.Text
            '  wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & do1i1
            Dim SAPI
            SAPI = CreateObject("SAPI.spvoice")

            SAPI.Speak(do1i1)

            ' duyet web
        ElseIf InStr(ct.Text, "web") > 0 Then
            ct.Text = Replace(ct.Text, "web", "")
            Dim do1i As String

            td.Show()
            do1i = ct.Text
            td.brwWebBrowser.Navigate(do1i)

            ' duyet wiki
        ElseIf InStr(chat.Text, "wiki") > 0 Then
            chat.Text = Replace(chat.Text, "wiki", "")
            Dim doi11 As String
            Dim rtt11 As String
            td.Show()
            doi11 = chat.Text
            rtt11 = Replace(doi11, " ", "+")
            td.brwWebBrowser.Navigate("http://vi.wikipedia.org/w/index.php?search=" & rtt11)

            ' kiem tra tra qn trg
        ElseIf InStr(chat.Text, "scan") > 0 Then
            chat.Text = Replace(chat.Text, "scan", "")
            Dim doi0 As String
            Dim rtt0 As String

            td.Show()
            doi0 = chat.Text
            rtt0 = Replace(doi0, " ", "+")
            td.brwWebBrowser.Navigate("https://www.google.com.vn/search?ie=UTF-8&hl=vi&q=" & rtt0)
            ' kiem tra picre
        ElseIf InStr(chat.Text, "image") > 0 Then
            chat.Text = Replace(chat.Text, "image", "")
            Dim anh As String
            Dim rttt As String
            td.Show()
            anh = chat.Text
            rttt = Replace(anh, " ", "+")
            td.brwWebBrowser.Navigate("https://www.google.com.vn/search?ie=UTF-8&hl=vi&q=" & rttt & "&source=lnms&tbm=isch")
            'anh lan 2
        ElseIf InStr(chat.Text, "picture") > 0 Then
            chat.Text = Replace(chat.Text, "picture", "")
            Dim an2h As String
            Dim rttt0 As String
            td.Show()
            an2h = chat.Text
            rttt0 = Replace(an2h, " ", "+")
            td.brwWebBrowser.Navigate("https://www.google.com.vn/search?ie=UTF-8&hl=vi&q=" & rttt0 & "&source=lnms&tbm=isch")
            ' kiem hoat hinh
        ElseIf InStr(chat.Text, "animation") > 0 Then
            chat.Text = Replace(chat.Text, "animation", "hoat hinh")
            Dim an2h23 As String
            Dim rttt13 As String
            td.Show()
            an2h23 = chat.Text
            rttt13 = Replace(an2h23, " ", "+")
            td.brwWebBrowser.Navigate("https://www.youtube.com/results?search_query=" & rttt13)
            ' kiem hoat hinh 2
        ElseIf InStr(chat.Text, "ani") > 0 Then
            chat.Text = Replace(chat.Text, "ani", "hoat hinh")
            Dim an2h233 As String
            Dim rttt133 As String
            td.Show()
            an2h233 = chat.Text
            rttt133 = Replace(an2h233, " ", "+")
            td.brwWebBrowser.Navigate("https://www.youtube.com/results?search_query=" & rttt133)
            ' hoat hinh vn
        ElseIf InStr(chat.Text, "hoat hinh") > 0 Then
            chat.Text = Replace(chat.Text, "hoat hinh", "phim hoat hinh")
            Dim an2h2334 As String
            Dim rttt1334 As String
            td.Show()
            an2h2334 = chat.Text
            rttt1334 = Replace(an2h2334, " ", "+")
            td.brwWebBrowser.Navigate("https://www.youtube.com/results?search_query=" & rttt1334)
            ' hoat hinh youtubbee
        ElseIf InStr(chat.Text, "youtube") > 0 Then
            chat.Text = Replace(chat.Text, "youtube", "")
            Dim awe As String
            Dim aew As String
            td.Show()
            awe = chat.Text
            aew = Replace(awe, " ", "+")
            td.brwWebBrowser.Navigate("https://www.youtube.com/results?search_query=" & aew)
            ' bing
        ElseIf InStr(chat.Text, "bing") > 0 Then
            chat.Text = Replace(chat.Text, "bing", "")
            Dim big As String
            Dim gib As String
            td.Show()
            big = chat.Text
            gib = Replace(big, " ", "+")
            td.brwWebBrowser.Navigate("http://www.bing.com/search?q=" & gib)
            ' bing image
        ElseIf InStr(chat.Text, "image bing") > 0 Then
            chat.Text = Replace(chat.Text, "image bing", "")
            Dim bigim As String
            Dim gibim As String
            td.Show()
            bigim = chat.Text
            gibim = Replace(bigim, " ", "+")
            td.brwWebBrowser.Navigate("http://www.bing.com/images/search?q=" & gibim)
            ' bing image2
        ElseIf InStr(chat.Text, "bing image") > 0 Then
            chat.Text = Replace(chat.Text, "bing image", "")
            Dim bigim2 As String
            Dim gibim2 As String
            td.Show()
            bigim2 = chat.Text
            gibim2 = Replace(bigim2, " ", "+")
            td.brwWebBrowser.Navigate("http://www.bing.com/images/search?q=" & gibim2)
            ' google
        ElseIf InStr(chat.Text, "google") > 0 Then
            chat.Text = Replace(chat.Text, "google", "")
            Dim ggl As String
            Dim glg As String
            td.Show()
            ggl = chat.Text
            glg = Replace(ggl, " ", "+")
            td.brwWebBrowser.Navigate("https://www.google.com.vn/search?ie=UTF-8&hl=vi&q=" & glg)
            ' yahoo
        ElseIf InStr(chat.Text, "yahoo") > 0 Then
            chat.Text = Replace(chat.Text, "yahoo", "")
            Dim yah As String
            Dim yahoo As String
            td.Show()
            yah = chat.Text
            yahoo = Replace(yah, " ", "+")
            td.brwWebBrowser.Navigate("https://vn.search.yahoo.com/search?q=" & yahoo)
            ' image yahoo
        ElseIf InStr(chat.Text, "yahoo image") > 0 Then
            chat.Text = Replace(chat.Text, "yahoo image", "")
            Dim yahim As String
            Dim yahooim As String
            td.Show()
            yahim = chat.Text
            yahooim = Replace(yahim, " ", "+")
            td.brwWebBrowser.Navigate("https://vn.images.search.yahoo.com/search/images?p=" & yahooim)
            ' image yahoo 2
        ElseIf InStr(chat.Text, "image yahoo") > 0 Then
            chat.Text = Replace(chat.Text, "image yahoo", "")
            Dim yahim2 As String
            Dim yahooim2 As String
            td.Show()
            yahim2 = chat.Text
            yahooim2 = Replace(yahim2, " ", "+")
            td.brwWebBrowser.Navigate("https://vn.images.search.yahoo.com/search/images?p=" & yahooim2)
            ' toan hoc math
        ElseIf InStr(chat.Text, "math") > 0 Then
            chat.Text = Replace(chat.Text, "math", "")
            Dim math As String
            Dim mathh As String
            td.Show()
            math = chat.Text
            mathh = Replace(math, " ", "+")
            td.brwWebBrowser.Navigate("http://coccoc.com/search/#query=" & mathh)
            ' ping
        ElseIf chat.Text = "ping" Then
            Dim kw As String

            Dim rt As String

          
            rt = getUrlSource("http://percat.esy.es/ip.php")

            kw = rt
            wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & "Ip pf you is " & kw
            MsgBox("Ip of you is " & kw)
            ' kiem tra oofline
        ElseIf chat.Text = "mini" Then
            hidemini.Show()
            Me.Hide()
        ElseIf chat.Text = "what is the time now" Then
            Dim dt As Date = Now
            ct.Text = "Now is " & dt
            en.Text = ct.Text
            vi.Text = "Bây giờ là " & dt

         
            '  wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & "Now is " & dt
            Dim SAPI
            SAPI = CreateObject("SAPI.spvoice")

            SAPI.Speak("Now is " & dt)
        ElseIf chat.Text = "what time is it" Then
            Dim dar As Date = Now
            ct.Text = "Now is " & dar
            en.Text = ct.Text
            vi.Text = "Bây giờ là " & dar

            'wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & "Now is " & dar
            Dim SAPI
            SAPI = CreateObject("SAPI.spvoice")

            SAPI.Speak("Now is " & dar)
        ElseIf chat.Text = "how old" Then

            td.Show()
            td.brwWebBrowser.Navigate("http://how-old.net")


            '  wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & "Open browser visit http://how-old.net"
            Dim SAPI
            SAPI = CreateObject("SAPI.spvoice")

            SAPI.Speak("Open browser visit http://how-old.net")
        ElseIf chat.Text = "google" Then

            td.Show()
            td.brwWebBrowser.Navigate("www.google.com.vn")
        ElseIf chat.Text = "coccoc" Then
            td.Show()
            td.brwWebBrowser.Navigate("www.coccoc.com/search")
        ElseIf chat.Text = "end" Then

           
            '  wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & "Goodbye, see you again"
            Dim SAPI
            SAPI = CreateObject("SAPI.spvoice")

            SAPI.Speak("Goodbye, see you again")
            End
        ElseIf chat.Text = "exit" Then
         
            ' wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & "Goodbye, see you again"
            Dim SAPI
            SAPI = CreateObject("SAPI.spvoice")

            SAPI.Speak("Goodbye, see you again")
            End
        ElseIf chat.Text = "mp3" Then

            Dim webAddress As String = "http://www.mp3.zing.vn"
            Process.Start(webAddress)
        ElseIf chat.Text = "luutru360" Then
            td.Show()
            td.brwWebBrowser.Navigate("www.luutru360.com")
        ElseIf chat.Text = "image" Then
            td.Show()
            td.brwWebBrowser.Navigate("www.bing.com/?scope=images")
        ElseIf chat.Text = "search image" Then
            td.Show()
            td.brwWebBrowser.Navigate("www.bing.com/?scope=images")
        ElseIf chat.Text = "scan image" Then
            td.Show()
            td.brwWebBrowser.Navigate("www.bing.com/?scope=images")
        ElseIf chat.Text = "youtube" Then
            ct.Text = "Please install flash to see the video => https://get.adobe.com/flashplayer/"


            'wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & "Please install flash to see the video"
            Dim SAPI
            SAPI = CreateObject("SAPI.spvoice")

            SAPI.Speak("Please install flash to see the video")
            Dim webAddressa As String = "https://get.adobe.com/flashplayer/"
            Process.Start(webAddressa)
        ElseIf chat.Text = "rename" Then
            MsgBox("Xin lỗi , tên chỉ được đặt một lần!", vbInformation, "Percat 7.0")
            ' nguoc lai thi getlink
        Else
            Dim noi As String
            Dim kq As String
            Dim boin As String
            nnt.Enabled = True
            en.Enabled = True
            boin = StrConv(chat.Text, 2)
            noi = Replace(boin, " ", "+")
            Dim qw As String

            qw = getUrlSource("http://percat.esy.es/sv/1.php?chat=" & noi)

            kq = qw
            ct.Text = kq
            t1.Text = ct.Text
            en.Text = "I will not get if you add these characters to"
            nnt.Enabled = True

            '  wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & t1.Text
          
            Dim SAPI01
            SAPI01 = CreateObject("SAPI.spvoice")

            SAPI01.Speak(t1.Text)

            ggg.Visible = True
            Label2.Visible = True
        End If
      
        vi.Text = "Vui lòng không viết in hoa, không thêm các kí tự hay dấu chấm ? ! @,..."

        t1.Text = ""
        Label1.Visible = False
        timm.Enabled = False
        nnt.Enabled = False
        q1.Enabled = False



    End Sub

    Private Sub q2_Tick(sender As Object, e As EventArgs) Handles q2.Tick
        nnt.Enabled = True
        ttt.Text = chat.Text

        ' neu rong
        If chat.Text = "" Then
            ct.Text = "You did not enter content!"
     
            ' wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & "You did not enter content!"
            Dim SAPI
            SAPI = CreateObject("SAPI.spvoice")

            SAPI.Speak("You did not enter content!")

            en.Text = ct.Text
            vi.Text = "Bạn chưa nhập nội dung!"

            ' duyet am thanh
        ElseIf InStr(chat.Text, "speak") > 0 Then
            chat.Text = Replace(chat.Text, "speak", "")
            Dim do1i1 As String
            do1i1 = chat.Text
            ' wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & do1i1
            Dim SAPI
            SAPI = CreateObject("SAPI.spvoice")

            SAPI.Speak(do1i1)
            ' duyet web
        ElseIf InStr(ct.Text, "web") > 0 Then
            ct.Text = Replace(ct.Text, "web", "")
            Dim do1i As String

            td.Show()
            do1i = ct.Text
            td.brwWebBrowser.Navigate(do1i)
            ' duyet wiki
        ElseIf InStr(chat.Text, "wiki") > 0 Then
            chat.Text = Replace(chat.Text, "wiki", "")
            Dim doi11 As String
            Dim rtt11 As String
            td.Show()
            doi11 = chat.Text
            rtt11 = Replace(doi11, " ", "+")
            td.brwWebBrowser.Navigate("http://vi.wikipedia.org/w/index.php?search=" & rtt11)
            ' kiem tra tra qn trg
        ElseIf InStr(chat.Text, "scan") > 0 Then
            chat.Text = Replace(chat.Text, "scan", "")
            Dim doi0 As String
            Dim rtt0 As String

            td.Show()
            doi0 = chat.Text
            rtt0 = Replace(doi0, " ", "+")
            td.brwWebBrowser.Navigate("https://www.google.com.vn/search?ie=UTF-8&hl=vi&q=" & rtt0)
            ' kiem tra picre
        ElseIf InStr(chat.Text, "image") > 0 Then
            chat.Text = Replace(chat.Text, "image", "")
            Dim anh As String
            Dim rttt As String
            td.Show()
            anh = chat.Text
            rttt = Replace(anh, " ", "+")
            td.brwWebBrowser.Navigate("https://www.google.com.vn/search?ie=UTF-8&hl=vi&q=" & rttt & "&source=lnms&tbm=isch")
            'anh lan 2
        ElseIf InStr(chat.Text, "picture") > 0 Then
            chat.Text = Replace(chat.Text, "picture", "")
            Dim an2h As String
            Dim rttt0 As String
            td.Show()
            an2h = chat.Text
            rttt0 = Replace(an2h, " ", "+")
            td.brwWebBrowser.Navigate("https://www.google.com.vn/search?ie=UTF-8&hl=vi&q=" & rttt0 & "&source=lnms&tbm=isch")
            ' kiem hoat hinh
        ElseIf InStr(chat.Text, "animation") > 0 Then
            chat.Text = Replace(chat.Text, "animation", "hoat hinh")
            Dim an2h23 As String
            Dim rttt13 As String
            td.Show()
            an2h23 = chat.Text
            rttt13 = Replace(an2h23, " ", "+")
            td.brwWebBrowser.Navigate("https://www.youtube.com/results?search_query=" & rttt13)
            ' kiem hoat hinh 2
        ElseIf InStr(chat.Text, "ani") > 0 Then
            chat.Text = Replace(chat.Text, "ani", "hoat hinh")
            Dim an2h233 As String
            Dim rttt133 As String
            td.Show()
            an2h233 = chat.Text
            rttt133 = Replace(an2h233, " ", "+")
            td.brwWebBrowser.Navigate("https://www.youtube.com/results?search_query=" & rttt133)
            ' hoat hinh vn
        ElseIf InStr(chat.Text, "hoat hinh") > 0 Then
            chat.Text = Replace(chat.Text, "hoat hinh", "phim hoat hinh")
            Dim an2h2334 As String
            Dim rttt1334 As String
            td.Show()
            an2h2334 = chat.Text
            rttt1334 = Replace(an2h2334, " ", "+")
            td.brwWebBrowser.Navigate("https://www.youtube.com/results?search_query=" & rttt1334)
            ' hoat hinh youtubbee
        ElseIf InStr(chat.Text, "youtube") > 0 Then
            chat.Text = Replace(chat.Text, "youtube", "")
            Dim awe As String
            Dim aew As String
            td.Show()
            awe = chat.Text
            aew = Replace(awe, " ", "+")
            td.brwWebBrowser.Navigate("https://www.youtube.com/results?search_query=" & aew)
            ' bing
        ElseIf InStr(chat.Text, "bing") > 0 Then
            chat.Text = Replace(chat.Text, "bing", "")
            Dim big As String
            Dim gib As String
            td.Show()
            big = chat.Text
            gib = Replace(big, " ", "+")
            td.brwWebBrowser.Navigate("http://www.bing.com/search?q=" & gib)
            ' bing image
        ElseIf InStr(chat.Text, "image bing") > 0 Then
            chat.Text = Replace(chat.Text, "image bing", "")
            Dim bigim As String
            Dim gibim As String
            td.Show()
            bigim = chat.Text
            gibim = Replace(bigim, " ", "+")
            td.brwWebBrowser.Navigate("http://www.bing.com/images/search?q=" & gibim)
            ' bing image2
        ElseIf InStr(chat.Text, "bing image") > 0 Then
            chat.Text = Replace(chat.Text, "bing image", "")
            Dim bigim2 As String
            Dim gibim2 As String
            td.Show()
            bigim2 = chat.Text
            gibim2 = Replace(bigim2, " ", "+")
            td.brwWebBrowser.Navigate("http://www.bing.com/images/search?q=" & gibim2)
            ' google
        ElseIf InStr(chat.Text, "google") > 0 Then
            chat.Text = Replace(chat.Text, "google", "")
            Dim ggl As String
            Dim glg As String
            td.Show()
            ggl = chat.Text
            glg = Replace(ggl, " ", "+")
            td.brwWebBrowser.Navigate("https://www.google.com.vn/search?ie=UTF-8&hl=vi&q=" & glg)
            ' yahoo
        ElseIf InStr(chat.Text, "yahoo") > 0 Then
            chat.Text = Replace(chat.Text, "yahoo", "")
            Dim yah As String
            Dim yahoo As String
            td.Show()
            yah = chat.Text
            yahoo = Replace(yah, " ", "+")
            td.brwWebBrowser.Navigate("https://vn.search.yahoo.com/search?q=" & yahoo)
            ' image yahoo
        ElseIf InStr(chat.Text, "yahoo image") > 0 Then
            chat.Text = Replace(chat.Text, "yahoo image", "")
            Dim yahim As String
            Dim yahooim As String
            td.Show()
            yahim = chat.Text
            yahooim = Replace(yahim, " ", "+")
            td.brwWebBrowser.Navigate("https://vn.images.search.yahoo.com/search/images?p=" & yahooim)
            ' image yahoo 2
        ElseIf InStr(chat.Text, "image yahoo") > 0 Then
            chat.Text = Replace(chat.Text, "image yahoo", "")
            Dim yahim2 As String
            Dim yahooim2 As String
            td.Show()
            yahim2 = chat.Text
            yahooim2 = Replace(yahim2, " ", "+")
            td.brwWebBrowser.Navigate("https://vn.images.search.yahoo.com/search/images?p=" & yahooim2)
            ' toan hoc math
        ElseIf InStr(chat.Text, "math") > 0 Then
            chat.Text = Replace(chat.Text, "math", "")
            Dim math As String
            Dim mathh As String
            td.Show()
            math = chat.Text
            mathh = Replace(math, " ", "+")
            td.brwWebBrowser.Navigate("http://coccoc.com/search/#query=" & mathh)
            ' ping
        ElseIf chat.Text = "ping" Then
            Dim kw As String

            Dim rt As String

            rt = getUrlSource("http://percat.esy.es/ip.php")

            kw = rt
   
            '   wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & "Ip of you is " & kw
            Dim SAPI
            SAPI = CreateObject("SAPI.spvoice")

            SAPI.Speak("Ip of you is " & kw)
            MsgBox("Ip of you is " & kw)
            ' kiem tra oofline
        ElseIf chat.Text = "mini" Then
            hidemini.Show()
            Me.Hide()
        ElseIf chat.Text = "what is the time now" Then
            Dim dt As Date = Now
            ct.Text = "Now is " & dt
            en.Text = ct.Text
            vi.Text = "Bây giờ là " & dt

           
            ' wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & "Now is " & dt
            Dim SAPI
            SAPI = CreateObject("SAPI.spvoice")

            SAPI.Speak("Now is " & dt)
        ElseIf chat.Text = "what time is it" Then
            Dim dar As Date = Now
            ct.Text = "Now is " & dar
            en.Text = ct.Text
            vi.Text = "Bây giờ là " & dar

            ' wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & "Now is " & dar
            Dim SAPI
            SAPI = CreateObject("SAPI.spvoice")

            SAPI.Speak("Now is " & dar)
        ElseIf chat.Text = "how old" Then

            td.Show()
            td.brwWebBrowser.Navigate("http://how-old.net")


            '  wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & "open browser visit http://how-old.net"
            Dim SAPI
            SAPI = CreateObject("SAPI.spvoice")

            SAPI.Speak("open browser visit http://how-old.net")
        ElseIf chat.Text = "google" Then

            td.Show()
            td.brwWebBrowser.Navigate("www.google.com.vn")
        ElseIf chat.Text = "coccoc" Then
            td.Show()
            td.brwWebBrowser.Navigate("www.coccoc.com/search")
        ElseIf chat.Text = "end" Then

            ' wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & "Goodbye, see you again"
            Dim SAPI
            SAPI = CreateObject("SAPI.spvoice")

            SAPI.Speak("Goodbye, see you again")
            End
        ElseIf chat.Text = "exit" Then
 
            '  wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & "Goodbye, see you again"
            Dim SAPI
            SAPI = CreateObject("SAPI.spvoice")

            SAPI.Speak("Goodbye, see you again")
            End
        ElseIf chat.Text = "mp3" Then

            Dim webAddress As String = "http://www.mp3.zing.vn"
            Process.Start(webAddress)
        ElseIf chat.Text = "luutru360" Then
            td.Show()
            td.brwWebBrowser.Navigate("www.luutru360.com")
        ElseIf chat.Text = "image" Then
            td.Show()
            td.brwWebBrowser.Navigate("www.bing.com/?scope=images")
        ElseIf chat.Text = "search image" Then
            td.Show()
            td.brwWebBrowser.Navigate("www.bing.com/?scope=images")
        ElseIf chat.Text = "scan image" Then
            td.Show()
            td.brwWebBrowser.Navigate("www.bing.com/?scope=images")
        ElseIf chat.Text = "youtube" Then
            ct.Text = "Please install flash to see the video => https://get.adobe.com/flashplayer/"

      
            ' wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & "please install flash to see the video"
            Dim SAPI
            SAPI = CreateObject("SAPI.spvoice")

            SAPI.Speak("please install flash to see the video")
            Dim webAddressa As String = "https://get.adobe.com/flashplayer/"
            Process.Start(webAddressa)
        ElseIf chat.Text = "rename" Then
            MsgBox("Xin lỗi , tên chỉ được đặt một lần!", vbInformation, "Percat 7.0")
            ' nguoc lai thi getlink
        Else
            Dim noi As String
            Dim kq As String
            Dim boin As String
            nnt.Enabled = True
            en.Enabled = True
            boin = StrConv(chat.Text, 2)
            noi = Replace(boin, " ", "+")
            Dim qw As String

         
            qw = getUrlSource("http://percat.esy.es/sv/2.php?chat=" & noi)

            kq = qw
            ct.Text = kq
            t1.Text = ct.Text
            en.Text = "I will not get if you add these characters to"
            nnt.Enabled = True
            ' wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & t1.Text
           
            Dim SAPI0
            SAPI0 = CreateObject("SAPI.spvoice")

            SAPI0.Speak(t1.Text)
            ggg.Visible = True
            Label2.Visible = True
        End If
       
        nnt.Enabled = False
        vi.Text = "Vui lòng không viết in hoa, không thêm các kí tự hay dấu chấm ? ! @,..."
        t1.Text = ""
        Label1.Visible = False

        timm.Enabled = False
        q2.Enabled = False

    End Sub

    Private Sub timm_Tick(sender As Object, e As EventArgs) Handles timm.Tick
        If InStr(ct.Text, "open") > 0 Then
            Dim doi78 As String
            Dim rtt78 As String

            ttt.Text = chat.Text
            doi78 = chat.Text
            rtt78 = Replace(doi78, " ", "+")
            td.brwWebBrowser.Navigate("https://www.google.com.vn/search?ie=UTF-8&hl=vi&q=" & rtt78)
            td.Show()
            bing.Visible = True
            yahoo.Visible = True
            google.Visible = True

            timm.Enabled = False
        ElseIf InStr(ct.Text, "web") > 0 Then
            ct.Text = Replace(ct.Text, "web", "")
            Dim do1i As String
            td.Show()
            do1i = ct.Text
            td.brwWebBrowser.Navigate(do1i)
        End If
    End Sub

    Private Sub nnt_Tick(sender As Object, e As EventArgs) Handles nnt.Tick
        so.Text = Int(Rnd() * 13)
        If so.Text = "0" Then
            percat2.Image = a.d1.Image
        ElseIf so.Text = "1" Then
            percat2.Image = a.d2.Image
        ElseIf so.Text = "2" Then
            percat2.Image = a.d3.Image
        ElseIf so.Text = "3" Then
            percat2.Image = a.d4.Image
        ElseIf so.Text = "4" Then
            percat2.Image = a.d5.Image
        ElseIf so.Text = "5" Then
            percat2.Image = a.d6.Image
        ElseIf so.Text = "6" Then
            percat2.Image = a.d7.Image
        ElseIf so.Text = "7" Then
            percat2.Image = a.d8.Image
        ElseIf so.Text = "8" Then
            percat2.Image = a.d9.Image
        ElseIf so.Text = "9" Then
            percat2.Image = a.d10.Image
        ElseIf so.Text = "10" Then
            percat2.Image = a.d11.Image
        ElseIf so.Text = "11" Then
            percat2.Image = a.d12.Image
        ElseIf so.Text = "12" Then
            percat2.Image = a.d13.Image
        ElseIf so.Text = "13" Then
            percat2.Image = a.d5.Image
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        percat2.Image = a.d3.Image
        en.Text = "Hello, I am is Percat"
        vi.Text = "Xin chào, Tôi là Percat"
        ' wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & en.Text
        Dim SAPI
        SAPI = CreateObject("SAPI.spvoice")

        SAPI.Speak(en.Text)
        percat2.Image = a.d5.Image
        Timer2.Enabled = True
        Timer1.Enabled = False
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        percat2.Image = a.d4.Image
        en.Text = "I am a virtual assistant"
        vi.Text = "Tôi là một trợ lí ảo"
        '  wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & en.Text
        Dim SAPI
        SAPI = CreateObject("SAPI.spvoice")

        SAPI.Speak(en.Text)
        percat2.Image = a.d5.Image
        Timer3.Enabled = True
        Timer2.Enabled = False
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        percat2.Image = a.d2.Image
        en.Text = "I will tell you by what I know"
        vi.Text = "Tôi sẽ cho bạn biết những gì mà tôi biết"
        '   wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & en.Text
        Dim SAPI
        SAPI = CreateObject("SAPI.spvoice")

        SAPI.Speak(en.Text)
        percat2.Image = a.d1.Image
        Timer4.Enabled = True
        Timer3.Enabled = False
    End Sub

    Private Sub Timer4_Tick(sender As Object, e As EventArgs) Handles Timer4.Tick
        percat2.Image = a.d5.Image
        en.Text = "Now, let's begin!"
        vi.Text = "Bây giờ, chúng ta hãy bắt đầu!"
        '  wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & en.Text
        Dim SAPI
        SAPI = CreateObject("SAPI.spvoice")

        SAPI.Speak(en.Text)
        percat2.Image = a.d3.Image
        Timer5.Enabled = True
        Timer4.Enabled = False
    End Sub

    Private Sub Timer5_Tick(sender As Object, e As EventArgs) Handles Timer5.Tick
        percat2.Image = a.d2.Image
        en.Text = "What is your nickname ?"
        vi.Text = "Biệt danh của bạn là gì ?"
        '  wmp.URL = "http://translate.google.com/translate_tts?tl=en&q=" & en.Text
        Dim SAPI
        SAPI = CreateObject("SAPI.spvoice")

        SAPI.Speak(en.Text)
        percat2.Image = a.d1.Image
        Me.Enabled = True
        ten.Visible = True
        bt1.Visible = True
        Timer5.Enabled = False
    End Sub

    Private Sub ten_TextChanged(sender As Object, e As EventArgs) Handles ten.TextChanged

    End Sub
    Private Sub chat_KeyPress(sender As Object, e As KeyPressEventArgs) Handles chat.KeyPress
        If e.KeyChar = Microsoft.VisualBasic.ChrW(Keys.Enter) Then
            sa.Text = Int(Rnd() * 2)
            Try

                If sa.Text = "0" Then
                    q1.Enabled = True
                    sss.Enabled = False
                ElseIf sa.Text = "1" Then
                    q2.Enabled = True
                    sss.Enabled = False
                End If
                sss.Enabled = False
            Catch
                sss.Enabled = False
            End Try
            Label1.Visible = True
        End If
    End Sub

    Private Sub chat_MouseClick(sender As Object, e As MouseEventArgs) Handles chat.MouseClick
        chat.Text = ""
    End Sub

  
    Private Sub chat_TextChanged(sender As Object, e As EventArgs) Handles chat.TextChanged

    End Sub

    Private Sub ggg_Click(sender As Object, e As EventArgs) Handles ggg.Click

        Dim doi78 As String
        Dim rtt78 As String

        ttt.Text = chat.Text
        doi78 = chat.Text
        rtt78 = Replace(doi78, " ", "+")
        td.brwWebBrowser.Navigate("https://www.google.com.vn/search?ie=UTF-8&hl=vi&q=" & rtt78)
        td.Show()
        bing.Visible = True
        yahoo.Visible = True
        google.Visible = True

        Label2.Visible = False
        ggg.Visible = False
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub yahoo_Click(sender As Object, e As EventArgs) Handles yahoo.Click

        Dim doi78 As String
        Dim rtt78 As String

        ttt.Text = chat.Text
        doi78 = chat.Text
        rtt78 = Replace(doi78, " ", "+")
        td.brwWebBrowser.Navigate("https://search.yahoo.com/search?p=" & rtt78)
        td.Show()

    End Sub

    Private Sub bing_Click(sender As Object, e As EventArgs) Handles bing.Click
        Dim doi78 As String
        Dim rtt78 As String

        ttt.Text = chat.Text
        doi78 = chat.Text
        rtt78 = Replace(doi78, " ", "+")
        td.brwWebBrowser.Navigate("http://www.bing.com/search?q=" & rtt78)
        td.Show()

    End Sub
End Class