﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class pc
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(pc))
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.LineShape1 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.ten = New System.Windows.Forms.TextBox()
        Me.bt1 = New System.Windows.Forms.Button()
        Me.send = New System.Windows.Forms.Button()
        Me.chat = New System.Windows.Forms.TextBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer4 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer5 = New System.Windows.Forms.Timer(Me.components)
        Me.n1 = New System.Windows.Forms.Timer(Me.components)
        Me.nnt = New System.Windows.Forms.Timer(Me.components)
        Me.timm = New System.Windows.Forms.Timer(Me.components)
        Me.q1 = New System.Windows.Forms.Timer(Me.components)
        Me.q2 = New System.Windows.Forms.Timer(Me.components)
        Me.sss = New System.Windows.Forms.Timer(Me.components)
        Me.ct = New System.Windows.Forms.Label()
        Me.so = New System.Windows.Forms.Label()
        Me.sw = New System.Windows.Forms.WebBrowser()
        Me.en = New System.Windows.Forms.Label()
        Me.vi = New System.Windows.Forms.Label()
        Me.sa = New System.Windows.Forms.Label()
        Me.ttt = New System.Windows.Forms.TextBox()
        Me.t1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.bing = New System.Windows.Forms.PictureBox()
        Me.yahoo = New System.Windows.Forms.PictureBox()
        Me.google = New System.Windows.Forms.PictureBox()
        Me.percat2 = New System.Windows.Forms.PictureBox()
        Me.wmp = New AxWMPLib.AxWindowsMediaPlayer()
        Me.ggg = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.bing, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.yahoo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.google, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.percat2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.wmp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ggg, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.LineShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(756, 693)
        Me.ShapeContainer1.TabIndex = 1
        Me.ShapeContainer1.TabStop = False
        '
        'LineShape1
        '
        Me.LineShape1.BorderColor = System.Drawing.Color.Red
        Me.LineShape1.Name = "LineShape1"
        Me.LineShape1.X1 = 2
        Me.LineShape1.X2 = 758
        Me.LineShape1.Y1 = 614
        Me.LineShape1.Y2 = 614
        '
        'ten
        '
        Me.ten.BackColor = System.Drawing.Color.Silver
        Me.ten.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ten.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ten.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ten.Location = New System.Drawing.Point(198, 516)
        Me.ten.Multiline = True
        Me.ten.Name = "ten"
        Me.ten.Size = New System.Drawing.Size(313, 31)
        Me.ten.TabIndex = 2
        Me.ten.Text = "Your name - Tên bạn"
        Me.ten.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.ten.Visible = False
        '
        'bt1
        '
        Me.bt1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bt1.Location = New System.Drawing.Point(518, 516)
        Me.bt1.Name = "bt1"
        Me.bt1.Size = New System.Drawing.Size(75, 34)
        Me.bt1.TabIndex = 3
        Me.bt1.Text = "&OK"
        Me.bt1.UseVisualStyleBackColor = True
        Me.bt1.Visible = False
        '
        'send
        '
        Me.send.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.send.Location = New System.Drawing.Point(641, 570)
        Me.send.Name = "send"
        Me.send.Size = New System.Drawing.Size(75, 23)
        Me.send.TabIndex = 4
        Me.send.Text = "&Send"
        Me.send.UseVisualStyleBackColor = True
        Me.send.Visible = False
        '
        'chat
        '
        Me.chat.BackColor = System.Drawing.Color.Silver
        Me.chat.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.chat.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chat.Location = New System.Drawing.Point(59, 570)
        Me.chat.Multiline = True
        Me.chat.Name = "chat"
        Me.chat.Size = New System.Drawing.Size(581, 22)
        Me.chat.TabIndex = 5
        Me.chat.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.chat.Visible = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 2000
        '
        'Timer2
        '
        Me.Timer2.Interval = 2000
        '
        'Timer3
        '
        Me.Timer3.Interval = 2000
        '
        'Timer4
        '
        Me.Timer4.Interval = 3000
        '
        'Timer5
        '
        Me.Timer5.Interval = 2000
        '
        'n1
        '
        Me.n1.Interval = 2000
        '
        'nnt
        '
        Me.nnt.Interval = 700
        '
        'timm
        '
        Me.timm.Enabled = True
        Me.timm.Interval = 200
        '
        'q1
        '
        Me.q1.Interval = 522
        '
        'q2
        '
        Me.q2.Interval = 560
        '
        'sss
        '
        Me.sss.Interval = 200
        '
        'ct
        '
        Me.ct.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ct.Location = New System.Drawing.Point(104, 397)
        Me.ct.Name = "ct"
        Me.ct.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ct.Size = New System.Drawing.Size(512, 19)
        Me.ct.TabIndex = 6
        Me.ct.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'so
        '
        Me.so.AutoSize = True
        Me.so.Location = New System.Drawing.Point(770, 507)
        Me.so.Name = "so"
        Me.so.Size = New System.Drawing.Size(0, 13)
        Me.so.TabIndex = 7
        '
        'sw
        '
        Me.sw.Location = New System.Drawing.Point(788, 507)
        Me.sw.MinimumSize = New System.Drawing.Size(20, 20)
        Me.sw.Name = "sw"
        Me.sw.Size = New System.Drawing.Size(27, 34)
        Me.sw.TabIndex = 11
        '
        'en
        '
        Me.en.AutoSize = True
        Me.en.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.en.Location = New System.Drawing.Point(33, 627)
        Me.en.Name = "en"
        Me.en.Size = New System.Drawing.Size(0, 19)
        Me.en.TabIndex = 12
        '
        'vi
        '
        Me.vi.AutoSize = True
        Me.vi.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.vi.Location = New System.Drawing.Point(33, 658)
        Me.vi.Name = "vi"
        Me.vi.Size = New System.Drawing.Size(0, 19)
        Me.vi.TabIndex = 13
        '
        'sa
        '
        Me.sa.AutoSize = True
        Me.sa.Location = New System.Drawing.Point(773, 472)
        Me.sa.Name = "sa"
        Me.sa.Size = New System.Drawing.Size(0, 13)
        Me.sa.TabIndex = 14
        '
        'ttt
        '
        Me.ttt.Location = New System.Drawing.Point(783, 465)
        Me.ttt.Name = "ttt"
        Me.ttt.Size = New System.Drawing.Size(16, 20)
        Me.ttt.TabIndex = 15
        '
        't1
        '
        Me.t1.Location = New System.Drawing.Point(776, 491)
        Me.t1.Name = "t1"
        Me.t1.Size = New System.Drawing.Size(12, 20)
        Me.t1.TabIndex = 16
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(662, 596)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 13)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Loading..."
        Me.Label1.Visible = False
        '
        'bing
        '
        Me.bing.Image = Global.Percat.My.Resources.Resources.Bing
        Me.bing.Location = New System.Drawing.Point(644, 243)
        Me.bing.Name = "bing"
        Me.bing.Size = New System.Drawing.Size(115, 101)
        Me.bing.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.bing.TabIndex = 10
        Me.bing.TabStop = False
        Me.bing.Visible = False
        '
        'yahoo
        '
        Me.yahoo.Image = Global.Percat.My.Resources.Resources.yahoo
        Me.yahoo.Location = New System.Drawing.Point(641, 136)
        Me.yahoo.Name = "yahoo"
        Me.yahoo.Size = New System.Drawing.Size(125, 101)
        Me.yahoo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.yahoo.TabIndex = 9
        Me.yahoo.TabStop = False
        Me.yahoo.Visible = False
        '
        'google
        '
        Me.google.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.google.Image = Global.Percat.My.Resources.Resources.google
        Me.google.Location = New System.Drawing.Point(641, 26)
        Me.google.Name = "google"
        Me.google.Size = New System.Drawing.Size(132, 104)
        Me.google.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.google.TabIndex = 8
        Me.google.TabStop = False
        Me.google.Visible = False
        '
        'percat2
        '
        Me.percat2.Image = Global.Percat.My.Resources.Resources._1
        Me.percat2.Location = New System.Drawing.Point(130, -32)
        Me.percat2.Name = "percat2"
        Me.percat2.Size = New System.Drawing.Size(474, 415)
        Me.percat2.TabIndex = 0
        Me.percat2.TabStop = False
        '
        'wmp
        '
        Me.wmp.Enabled = True
        Me.wmp.Location = New System.Drawing.Point(763, 10)
        Me.wmp.Name = "wmp"
        Me.wmp.OcxState = CType(resources.GetObject("wmp.OcxState"), System.Windows.Forms.AxHost.State)
        Me.wmp.Size = New System.Drawing.Size(10, 10)
        Me.wmp.TabIndex = 18
        '
        'ggg
        '
        Me.ggg.BackColor = System.Drawing.Color.Silver
        Me.ggg.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.ggg.Image = Global.Percat.My.Resources.Resources.google
        Me.ggg.Location = New System.Drawing.Point(335, 172)
        Me.ggg.Name = "ggg"
        Me.ggg.Size = New System.Drawing.Size(69, 51)
        Me.ggg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.ggg.TabIndex = 19
        Me.ggg.TabStop = False
        Me.ggg.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Silver
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(306, 149)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(134, 20)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Click ico google"
        Me.Label2.Visible = False
        '
        'pc
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Gray
        Me.ClientSize = New System.Drawing.Size(756, 693)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ggg)
        Me.Controls.Add(Me.wmp)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.t1)
        Me.Controls.Add(Me.ttt)
        Me.Controls.Add(Me.sa)
        Me.Controls.Add(Me.vi)
        Me.Controls.Add(Me.en)
        Me.Controls.Add(Me.sw)
        Me.Controls.Add(Me.bing)
        Me.Controls.Add(Me.yahoo)
        Me.Controls.Add(Me.google)
        Me.Controls.Add(Me.so)
        Me.Controls.Add(Me.ct)
        Me.Controls.Add(Me.chat)
        Me.Controls.Add(Me.send)
        Me.Controls.Add(Me.bt1)
        Me.Controls.Add(Me.ten)
        Me.Controls.Add(Me.percat2)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "pc"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Percat 7.0"
        CType(Me.bing, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.yahoo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.google, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.percat2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.wmp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ggg, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents percat2 As System.Windows.Forms.PictureBox
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents LineShape1 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents ten As System.Windows.Forms.TextBox
    Friend WithEvents bt1 As System.Windows.Forms.Button
    Friend WithEvents send As System.Windows.Forms.Button
    Friend WithEvents chat As System.Windows.Forms.TextBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents Timer3 As System.Windows.Forms.Timer
    Friend WithEvents Timer4 As System.Windows.Forms.Timer
    Friend WithEvents Timer5 As System.Windows.Forms.Timer
    Friend WithEvents n1 As System.Windows.Forms.Timer
    Friend WithEvents nnt As System.Windows.Forms.Timer
    Friend WithEvents timm As System.Windows.Forms.Timer
    Friend WithEvents q1 As System.Windows.Forms.Timer
    Friend WithEvents q2 As System.Windows.Forms.Timer
    Friend WithEvents sss As System.Windows.Forms.Timer
    Friend WithEvents ct As System.Windows.Forms.Label
    Friend WithEvents so As System.Windows.Forms.Label
    Friend WithEvents google As System.Windows.Forms.PictureBox
    Friend WithEvents yahoo As System.Windows.Forms.PictureBox
    Friend WithEvents bing As System.Windows.Forms.PictureBox
    Friend WithEvents sw As System.Windows.Forms.WebBrowser
    Friend WithEvents en As System.Windows.Forms.Label
    Friend WithEvents vi As System.Windows.Forms.Label
    Friend WithEvents sa As System.Windows.Forms.Label
    Friend WithEvents ttt As System.Windows.Forms.TextBox
    Friend WithEvents t1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents wmp As AxWMPLib.AxWindowsMediaPlayer
    Friend WithEvents ggg As System.Windows.Forms.PictureBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
