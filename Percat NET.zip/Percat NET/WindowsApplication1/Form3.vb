﻿Public Class td

    Private Sub brwWebBrowser_DocumentCompleted(sender As Object, e As WebBrowserDocumentCompletedEventArgs) Handles brwWebBrowser.DocumentCompleted
        pc.Enabled = True
    End Sub

    Private Sub td_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        pc.Enabled = True
    End Sub

    Private Sub td_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        pc.q1.Enabled = False
        pc.q2.Enabled = False
    End Sub
End Class