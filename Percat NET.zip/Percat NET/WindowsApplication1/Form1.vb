﻿Public Class load



    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If ss.Text = "0" Then
            q7.ForeColor = Color.Lime
            q1.ForeColor = Color.RoyalBlue
            ss.Text = "1"
        ElseIf ss.Text = "1" Then
            q1.ForeColor = Color.Lime
            q2.ForeColor = Color.RoyalBlue
            ss.Text = "2"
        ElseIf ss.Text = "2" Then
            q2.ForeColor = Color.Lime
            q3.ForeColor = Color.RoyalBlue
            ss.Text = "3"
        ElseIf ss.Text = "3" Then
            q3.ForeColor = Color.Lime
            q4.ForeColor = Color.RoyalBlue
            ss.Text = "4"
        ElseIf ss.Text = "4" Then
            q4.ForeColor = Color.Lime
            q5.ForeColor = Color.RoyalBlue
            ss.Text = "5"
        ElseIf ss.Text = "5" Then
            q5.ForeColor = Color.Lime
            q6.ForeColor = Color.RoyalBlue
            ss.Text = "6"
        ElseIf ss.Text = "6" Then
            q6.ForeColor = Color.Lime
            q7.ForeColor = Color.RoyalBlue
            ss.Text = "0"
        End If
    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles q6.Click

    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        If ss.Text = "0" Then
            q7.ForeColor = Color.Black
            q1.ForeColor = Color.Red
            ss.Text = "1"
        ElseIf ss.Text = "1" Then
            q1.ForeColor = Color.Black
            q2.ForeColor = Color.Red
            ss.Text = "2"
        ElseIf ss.Text = "2" Then
            q2.ForeColor = Color.Black
            q3.ForeColor = Color.Red
            ss.Text = "3"
        ElseIf ss.Text = "3" Then
            q3.ForeColor = Color.Black
            q4.ForeColor = Color.Red
            ss.Text = "4"
        ElseIf ss.Text = "4" Then
            q4.ForeColor = Color.Black
            q5.ForeColor = Color.Red
            ss.Text = "5"
        ElseIf ss.Text = "5" Then
            q5.ForeColor = Color.Black
            q6.ForeColor = Color.Red
            ss.Text = "6"
        ElseIf ss.Text = "6" Then
            q6.ForeColor = Color.Black
            q7.ForeColor = Color.Red
            ss.Text = "0"
        End If
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        Dim pc As New pc()
        Timer3.Enabled = False
        pc.Show()
        Me.Hide()
    End Sub

    Private Sub nnt_Tick(sender As Object, e As EventArgs) Handles nnt.Tick
        so.Text = Int(Rnd() * 13)
        If so.Text = "0" Then
            percat.Image = a.d1.Image
        ElseIf so.Text = "1" Then
            percat.Image = a.d2.Image
        ElseIf so.Text = "2" Then
            percat.Image = a.d3.Image
        ElseIf so.Text = "3" Then
            percat.Image = a.d4.Image
        ElseIf so.Text = "4" Then
            percat.Image = a.d5.Image
        ElseIf so.Text = "5" Then
            percat.Image = a.d6.Image
        ElseIf so.Text = "6" Then
            percat.Image = a.d7.Image
        ElseIf so.Text = "7" Then
            percat.Image = a.d8.Image
        ElseIf so.Text = "8" Then
            percat.Image = a.d9.Image
        ElseIf so.Text = "9" Then
            percat.Image = a.d10.Image
        ElseIf so.Text = "10" Then
            percat.Image = a.d11.Image
        ElseIf so.Text = "11" Then
            percat.Image = a.d12.Image
        ElseIf so.Text = "12" Then
            percat.Image = a.d13.Image
        ElseIf so.Text = "13" Then
            percat.Image = a.d5.Image
        End If
    End Sub
End Class
