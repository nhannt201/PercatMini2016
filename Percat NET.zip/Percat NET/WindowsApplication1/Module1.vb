﻿'Option Strict Off
'Option Explicit On

Imports VB = Microsoft.VisualBasic

Public Module Module1


    '=========================================================
    Public Declare Function InternetOpen Lib "wininet.dll" Alias "InternetOpenA" (ByVal sAgent As String, ByVal lAccessType As Integer, ByVal sProxyName As String, ByVal sProxyBypass As String, ByVal lFlags As Integer) As Integer
    Public Declare Function InternetOpenUrl Lib "wininet.dll" Alias "InternetOpenUrlA" (ByVal hInternetSession As Integer, ByVal sURL As String, ByVal sHeaders As String, ByVal lHeadersLength As Integer, ByVal lFlags As Integer, ByVal lContext As Integer) As Integer
    Public Declare Function InternetReadFile Lib "wininet.dll" (ByVal hFile As Integer, ByVal sBuffer As String, ByVal lNumBytesToRead As Integer, ByRef lNumberOfBytesRead As Integer) As Short
    Public Declare Function InternetCloseHandle Lib "wininet.dll" (ByVal hInet As Integer) As Short

    Public Const IF_FROM_CACHE As Integer = &H1000000
    Public Const IF_MAKE_PERSISTENT As Integer = &H2000000
    Public Const IF_NO_CACHE_WRITE As Integer = &H4000000
    Private Const BUFFER_LEN As Short = 256
    Public Function GetUrlSource(ByRef sURL As String) As String
        GetUrlSource = 0
        '#Const def_GetUrlSource = True
#If def_GetUrlSource Then
        ' VBto upgrade warning: sData As String	OnWrite(???, String)
        Dim sBuffer As New VB6.FixedLengthString(BUFFER_LEN), iResult As Short, sData As String = ""
        Dim hInternet As Integer, hSession As Integer, lReturn As Integer
        hSession = InternetOpen("vb wininet", 1, vbNullString, vbNullString, 0)
        If hSession Then hInternet = InternetOpenUrl(hSession, sURL, vbNullString, 0, IF_NO_CACHE_WRITE, 0)
        If hInternet Then

            iResult = InternetReadFile(hInternet, sBuffer, BUFFER_LEN, lReturn)
            sData = sBuffer

            Do While lReturn<>0
                iResult = InternetReadFile(hInternet, sBuffer, BUFFER_LEN, lReturn)
                sData += Mid(sBuffer, 1, lReturn)
            Loop
        End If
        iResult = InternetCloseHandle(hInternet)
        GetUrlSource = sData
#End If ' def_GetUrlSource
    End Function

End Module