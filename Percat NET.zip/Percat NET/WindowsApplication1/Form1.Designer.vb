﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class load
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(load))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.nnt = New System.Windows.Forms.Timer(Me.components)
        Me.q1 = New System.Windows.Forms.Label()
        Me.q2 = New System.Windows.Forms.Label()
        Me.q3 = New System.Windows.Forms.Label()
        Me.q4 = New System.Windows.Forms.Label()
        Me.q5 = New System.Windows.Forms.Label()
        Me.q6 = New System.Windows.Forms.Label()
        Me.q7 = New System.Windows.Forms.Label()
        Me.so = New System.Windows.Forms.Label()
        Me.ss = New System.Windows.Forms.Label()
        Me.percat = New System.Windows.Forms.PictureBox()
        CType(Me.percat, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 99
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        '
        'Timer3
        '
        Me.Timer3.Enabled = True
        Me.Timer3.Interval = 5000
        '
        'nnt
        '
        Me.nnt.Enabled = True
        Me.nnt.Interval = 800
        '
        'q1
        '
        Me.q1.AutoSize = True
        Me.q1.Font = New System.Drawing.Font("Tahoma", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.q1.Location = New System.Drawing.Point(251, 454)
        Me.q1.Name = "q1"
        Me.q1.Size = New System.Drawing.Size(52, 58)
        Me.q1.TabIndex = 1
        Me.q1.Text = "L"
        '
        'q2
        '
        Me.q2.AutoSize = True
        Me.q2.Font = New System.Drawing.Font("Tahoma", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.q2.Location = New System.Drawing.Point(289, 454)
        Me.q2.Name = "q2"
        Me.q2.Size = New System.Drawing.Size(55, 58)
        Me.q2.TabIndex = 2
        Me.q2.Text = "o"
        '
        'q3
        '
        Me.q3.AutoSize = True
        Me.q3.Font = New System.Drawing.Font("Tahoma", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.q3.Location = New System.Drawing.Point(327, 454)
        Me.q3.Name = "q3"
        Me.q3.Size = New System.Drawing.Size(54, 58)
        Me.q3.TabIndex = 3
        Me.q3.Text = "a"
        '
        'q4
        '
        Me.q4.AutoSize = True
        Me.q4.Font = New System.Drawing.Font("Tahoma", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.q4.Location = New System.Drawing.Point(365, 454)
        Me.q4.Name = "q4"
        Me.q4.Size = New System.Drawing.Size(55, 58)
        Me.q4.TabIndex = 4
        Me.q4.Text = "d"
        '
        'q5
        '
        Me.q5.AutoSize = True
        Me.q5.Font = New System.Drawing.Font("Tahoma", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.q5.Location = New System.Drawing.Point(403, 454)
        Me.q5.Name = "q5"
        Me.q5.Size = New System.Drawing.Size(39, 58)
        Me.q5.TabIndex = 5
        Me.q5.Text = "i"
        '
        'q6
        '
        Me.q6.AutoSize = True
        Me.q6.Font = New System.Drawing.Font("Tahoma", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.q6.Location = New System.Drawing.Point(443, 454)
        Me.q6.Name = "q6"
        Me.q6.Size = New System.Drawing.Size(56, 58)
        Me.q6.TabIndex = 6
        Me.q6.Text = "n"
        '
        'q7
        '
        Me.q7.AutoSize = True
        Me.q7.Font = New System.Drawing.Font("Tahoma", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.q7.ForeColor = System.Drawing.Color.Black
        Me.q7.Location = New System.Drawing.Point(481, 454)
        Me.q7.Name = "q7"
        Me.q7.Size = New System.Drawing.Size(55, 58)
        Me.q7.TabIndex = 7
        Me.q7.Text = "g"
        '
        'so
        '
        Me.so.AutoSize = True
        Me.so.Location = New System.Drawing.Point(886, 541)
        Me.so.Name = "so"
        Me.so.Size = New System.Drawing.Size(13, 13)
        Me.so.TabIndex = 8
        Me.so.Text = "0"
        '
        'ss
        '
        Me.ss.AutoSize = True
        Me.ss.Location = New System.Drawing.Point(867, 541)
        Me.ss.Name = "ss"
        Me.ss.Size = New System.Drawing.Size(13, 13)
        Me.ss.TabIndex = 9
        Me.ss.Text = "0"
        '
        'percat
        '
        Me.percat.Image = Global.Percat.My.Resources.Resources._1
        Me.percat.Location = New System.Drawing.Point(156, 12)
        Me.percat.Name = "percat"
        Me.percat.Size = New System.Drawing.Size(447, 439)
        Me.percat.TabIndex = 0
        Me.percat.TabStop = False
        '
        'load
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Gray
        Me.ClientSize = New System.Drawing.Size(785, 563)
        Me.Controls.Add(Me.ss)
        Me.Controls.Add(Me.so)
        Me.Controls.Add(Me.q7)
        Me.Controls.Add(Me.q6)
        Me.Controls.Add(Me.q5)
        Me.Controls.Add(Me.q4)
        Me.Controls.Add(Me.q3)
        Me.Controls.Add(Me.q2)
        Me.Controls.Add(Me.q1)
        Me.Controls.Add(Me.percat)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"),System.Drawing.Icon)
        Me.Name = "load"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Percat 6.0"
        CType(Me.percat,System.ComponentModel.ISupportInitialize).EndInit
        Me.ResumeLayout(false)
        Me.PerformLayout

End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents Timer3 As System.Windows.Forms.Timer
    Friend WithEvents nnt As System.Windows.Forms.Timer
    Friend WithEvents percat As System.Windows.Forms.PictureBox
    Friend WithEvents q1 As System.Windows.Forms.Label
    Friend WithEvents q2 As System.Windows.Forms.Label
    Friend WithEvents q3 As System.Windows.Forms.Label
    Friend WithEvents q4 As System.Windows.Forms.Label
    Friend WithEvents q5 As System.Windows.Forms.Label
    Friend WithEvents q6 As System.Windows.Forms.Label
    Friend WithEvents q7 As System.Windows.Forms.Label
    Friend WithEvents so As System.Windows.Forms.Label
    Friend WithEvents ss As System.Windows.Forms.Label

End Class
