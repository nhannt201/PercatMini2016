﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class a
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.d13 = New System.Windows.Forms.PictureBox()
        Me.d12 = New System.Windows.Forms.PictureBox()
        Me.d11 = New System.Windows.Forms.PictureBox()
        Me.d10 = New System.Windows.Forms.PictureBox()
        Me.d9 = New System.Windows.Forms.PictureBox()
        Me.d8 = New System.Windows.Forms.PictureBox()
        Me.d7 = New System.Windows.Forms.PictureBox()
        Me.d6 = New System.Windows.Forms.PictureBox()
        Me.d5 = New System.Windows.Forms.PictureBox()
        Me.d4 = New System.Windows.Forms.PictureBox()
        Me.d3 = New System.Windows.Forms.PictureBox()
        Me.d2 = New System.Windows.Forms.PictureBox()
        Me.d1 = New System.Windows.Forms.PictureBox()
        CType(Me.d13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.d12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.d11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.d10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.d9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.d8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.d7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.d6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.d5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.d4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.d3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.d2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.d1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'd13
        '
        Me.d13.Image = Global.Percat.My.Resources.Resources._13
        Me.d13.Location = New System.Drawing.Point(172, 72)
        Me.d13.Name = "d13"
        Me.d13.Size = New System.Drawing.Size(29, 25)
        Me.d13.TabIndex = 12
        Me.d13.TabStop = False
        '
        'd12
        '
        Me.d12.Image = Global.Percat.My.Resources.Resources._12
        Me.d12.Location = New System.Drawing.Point(123, 72)
        Me.d12.Name = "d12"
        Me.d12.Size = New System.Drawing.Size(29, 25)
        Me.d12.TabIndex = 11
        Me.d12.TabStop = False
        '
        'd11
        '
        Me.d11.Image = Global.Percat.My.Resources.Resources._111
        Me.d11.Location = New System.Drawing.Point(75, 72)
        Me.d11.Name = "d11"
        Me.d11.Size = New System.Drawing.Size(29, 25)
        Me.d11.TabIndex = 10
        Me.d11.TabStop = False
        '
        'd10
        '
        Me.d10.Image = Global.Percat.My.Resources.Resources._10
        Me.d10.Location = New System.Drawing.Point(23, 72)
        Me.d10.Name = "d10"
        Me.d10.Size = New System.Drawing.Size(29, 25)
        Me.d10.TabIndex = 9
        Me.d10.TabStop = False
        '
        'd9
        '
        Me.d9.Image = Global.Percat.My.Resources.Resources._9
        Me.d9.Location = New System.Drawing.Point(425, 23)
        Me.d9.Name = "d9"
        Me.d9.Size = New System.Drawing.Size(29, 25)
        Me.d9.TabIndex = 8
        Me.d9.TabStop = False
        '
        'd8
        '
        Me.d8.Image = Global.Percat.My.Resources.Resources._8
        Me.d8.Location = New System.Drawing.Point(370, 23)
        Me.d8.Name = "d8"
        Me.d8.Size = New System.Drawing.Size(29, 25)
        Me.d8.TabIndex = 7
        Me.d8.TabStop = False
        '
        'd7
        '
        Me.d7.Image = Global.Percat.My.Resources.Resources._7
        Me.d7.Location = New System.Drawing.Point(323, 23)
        Me.d7.Name = "d7"
        Me.d7.Size = New System.Drawing.Size(29, 25)
        Me.d7.TabIndex = 6
        Me.d7.TabStop = False
        '
        'd6
        '
        Me.d6.Image = Global.Percat.My.Resources.Resources._6
        Me.d6.Location = New System.Drawing.Point(273, 23)
        Me.d6.Name = "d6"
        Me.d6.Size = New System.Drawing.Size(29, 25)
        Me.d6.TabIndex = 5
        Me.d6.TabStop = False
        '
        'd5
        '
        Me.d5.Image = Global.Percat.My.Resources.Resources._5
        Me.d5.Location = New System.Drawing.Point(220, 23)
        Me.d5.Name = "d5"
        Me.d5.Size = New System.Drawing.Size(29, 25)
        Me.d5.TabIndex = 4
        Me.d5.TabStop = False
        '
        'd4
        '
        Me.d4.Image = Global.Percat.My.Resources.Resources._4
        Me.d4.Location = New System.Drawing.Point(172, 23)
        Me.d4.Name = "d4"
        Me.d4.Size = New System.Drawing.Size(29, 25)
        Me.d4.TabIndex = 3
        Me.d4.TabStop = False
        '
        'd3
        '
        Me.d3.Image = Global.Percat.My.Resources.Resources._3
        Me.d3.Location = New System.Drawing.Point(123, 23)
        Me.d3.Name = "d3"
        Me.d3.Size = New System.Drawing.Size(29, 25)
        Me.d3.TabIndex = 2
        Me.d3.TabStop = False
        '
        'd2
        '
        Me.d2.Image = Global.Percat.My.Resources.Resources._2
        Me.d2.Location = New System.Drawing.Point(75, 23)
        Me.d2.Name = "d2"
        Me.d2.Size = New System.Drawing.Size(29, 25)
        Me.d2.TabIndex = 1
        Me.d2.TabStop = False
        '
        'd1
        '
        Me.d1.Image = Global.Percat.My.Resources.Resources._1
        Me.d1.Location = New System.Drawing.Point(23, 23)
        Me.d1.Name = "d1"
        Me.d1.Size = New System.Drawing.Size(29, 25)
        Me.d1.TabIndex = 0
        Me.d1.TabStop = False
        '
        'a
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(491, 339)
        Me.Controls.Add(Me.d13)
        Me.Controls.Add(Me.d12)
        Me.Controls.Add(Me.d11)
        Me.Controls.Add(Me.d10)
        Me.Controls.Add(Me.d9)
        Me.Controls.Add(Me.d8)
        Me.Controls.Add(Me.d7)
        Me.Controls.Add(Me.d6)
        Me.Controls.Add(Me.d5)
        Me.Controls.Add(Me.d4)
        Me.Controls.Add(Me.d3)
        Me.Controls.Add(Me.d2)
        Me.Controls.Add(Me.d1)
        Me.Name = "a"
        Me.Text = "Form2"
        CType(Me.d13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.d12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.d11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.d10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.d9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.d8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.d7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.d6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.d5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.d4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.d3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.d2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.d1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents d1 As System.Windows.Forms.PictureBox
    Friend WithEvents d2 As System.Windows.Forms.PictureBox
    Friend WithEvents d3 As System.Windows.Forms.PictureBox
    Friend WithEvents d4 As System.Windows.Forms.PictureBox
    Friend WithEvents d5 As System.Windows.Forms.PictureBox
    Friend WithEvents d6 As System.Windows.Forms.PictureBox
    Friend WithEvents d7 As System.Windows.Forms.PictureBox
    Friend WithEvents d8 As System.Windows.Forms.PictureBox
    Friend WithEvents d9 As System.Windows.Forms.PictureBox
    Friend WithEvents d10 As System.Windows.Forms.PictureBox
    Friend WithEvents d11 As System.Windows.Forms.PictureBox
    Friend WithEvents d12 As System.Windows.Forms.PictureBox
    Friend WithEvents d13 As System.Windows.Forms.PictureBox
End Class
