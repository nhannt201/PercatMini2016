﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        server.Items.Add("Tiếng Anh")
        server.Items.Add("Tiếng Việt")
        xd.Text = "Đã kết nối máy chủ!"
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        xd.Text = "Kết nối máy chủ..."
        Button1.Enabled = False
        If hoi.Text = "" Or dap1.Text = "" Or dap2.Text = "" Then
            xd.Text = "Đang cảnh báo!"
            MsgBox("Vui lòng nhập dữ liệu vào các phần bị bỏ trống!", vbInformation, "Cảnh báo!")
            Button1.Enabled = True
        Else
            If server.Text = "Tiếng Anh" Then
                xd.Text = "Đã gửi dữ liệu to Server 1!"
                Dim cauhoi As String = RemoveSign4VietnameseString(StrConv(hoi.Text, 2))
                Dim m1 As String = System.Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(dap1.Text))
                Dim m2 As String = System.Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(dap2.Text))
                Dim get1 As String = New System.Net.WebClient().DownloadString("http://percat.esy.es/ver2/ads.php?cau=" & cauhoi & "&dap=" & m1)
                Dim get2 As String = New System.Net.WebClient().DownloadString("http://percat.esy.es/ver2/ads2.php?cau=" & cauhoi & "&dap=" & m2)
                '      Dim u As String = replace("[^a-zA-Z0-9]", '', $str)
                Button1.Enabled = True
            ElseIf server.Text = "Tiếng Việt" Then
                xd.Text = "Đã gửi dữ liệu to Server 2!"
                Dim cauhoi2 As String = RemoveSign4VietnameseString(StrConv(hoi.Text, 2))
                Dim m3 As String = System.Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(dap1.Text))
                Dim m4 As String = System.Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(dap2.Text))
                Dim get1 As String = New System.Net.WebClient().DownloadString("http://percat.esy.es/ver2/ads3.php?cau=" & cauhoi2 & "&dap=" & m3)
                Dim get2 As String = New System.Net.WebClient().DownloadString("http://percat.esy.es/ver2/ads4.php?cau=" & cauhoi2 & "&dap=" & m4)
                Button1.Enabled = True
            Else
                xd.Text = "Không thể xác định máy chủ đã chọn!"
                Button1.Enabled = True
            End If
        End If
        ' Dim asas As String = bokitu(hoi.Text)
        'bokitu()
    End Sub

    Sub bokitu()
        Dim i2 As String = Replace("~", "", "")
        Dim i3 As String = Replace(",", "", i2)
        Dim i4 As String = Replace("'", "", i3)
        Dim i5 As String = Replace("`", "", i4)
        Dim i6 As String = Replace("!", "", i5)
        Dim i7 As String = Replace("@", "", i6)
        Dim i8 As String = Replace("#", "", i7)
        Dim i9 As String = Replace("$", "", i8)
        Dim i10 As String = Replace("%", "", i9)
        Dim i11 As String = Replace("^", "", i10)
        Dim i12 As String = Replace("&", "", i11)
        Dim i13 As String = Replace("*", "", i12)
        Dim i14 As String = Replace("(", "", i13)
        Dim i15 As String = Replace(")", "", i14)
        Dim i16 As String = Replace("_", "", i15)
        Dim i17 As String = Replace("-", "", i16)
        Dim i18 As String = Replace("=", "", i17)
        Dim i19 As String = Replace("/", "", i18)
        Dim i20 As String = Replace("[", "", i19)
        Dim i21 As String = Replace("]", "", i20)
        Dim i22 As String = Replace("{", "", i21)
        Dim i23 As String = Replace("}", "", i22)
        Dim i24 As String = Replace(":", "", i23)
        Dim i25 As String = Replace(";", "", i24)
        Dim i26 As String = Replace("\", "", i25)
        Dim i27 As String = Replace("|", "", i26)
        Dim i28 As String = Replace("<", "", i27)
        Dim i29 As String = Replace(">", "", i28)
        Dim i30 As String = Replace("?", "", i29)
        Dim i31 As String = Replace(",", "", i30)
        Dim i32 As String = Replace(".", "", i31)
        MsgBox(i32)
    End Sub

    Private Sub server_SelectedIndexChanged(sender As Object, e As EventArgs) Handles server.SelectedIndexChanged
        If server.Text = "Tiếng Anh" Then
            xd.Text = "Đã kết nối đến Server Tiếng Anh"
        ElseIf server.Text = "Tiếng Việt" Then
            xd.Text = "Đã kết nối đến Server Tiếng Việt"
        End If
    End Sub


    Private Shared ReadOnly VietnameseSigns As String() = New String() {"aAeEoOuUiIdDyY", "áàạảãâấầậẩẫăắằặẳẵ", "ÁÀẠẢÃÂẤẦẬẨẪĂẮẰẶẲẴ", "éèẹẻẽêếềệểễ", "ÉÈẸẺẼÊẾỀỆỂỄ", "óòọỏõôốồộổỗơớờợởỡ", _
                                                                            "ÓÒỌỎÕÔỐỒỘỔỖƠỚỜỢỞỠ", "úùụủũưứừựửữ", "ÚÙỤỦŨƯỨỪỰỬỮ", "íìịỉĩ", "ÍÌỊỈĨ", "đ", _
                                                                            "Đ", "ýỳỵỷỹ", "ÝỲỴỶỸ"}

    Public Shared Function RemoveSign4VietnameseString(ByVal str As String) As String
        For i As Integer = 1 To VietnameseSigns.Length - 1
            For j As Integer = 0 To VietnameseSigns(i).Length - 1
                str = str.Replace(VietnameseSigns(i)(j), VietnameseSigns(0)(i - 1))
            Next
        Next
        Return str
    End Function
End Class
