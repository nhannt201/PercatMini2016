﻿Public Class load

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim a As String = "468, 285"
        If a = "468, 285" Then
            ' p1.Location = New Point(p1.Location.X - 1, p1.Location.Y - 1)
            p1.Width = p1.Width - 1
            p1.Height = p1.Height - 1
        ElseIf p1.Width <= 10 Or p1.Height <= 10 Then
            Timer1.Stop()
        End If
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        p1.Width = p1.Width - 10
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        p2.Width = p2.Width + 10
    End Sub

    Private Sub Timer4_Tick(sender As Object, e As EventArgs) Handles Timer4.Tick
        p2.Width = p2.Width - 10

    End Sub
End Class
